#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

ACTION=$1

SYSTEM_TYPE=""
PLUGIN_DIR=""
LAN_IF_NAME=""
VENDOR=""
MODEL=""
VERSION=""
PLUGIN_VERSION=""
LAN_IF_ADDR=""
LAN_IF_MAC=""
KERNEL=""
DHCP_LEASES=""

DAEMON_LOG=""
CORE_TAR=""
NOHUP_CMD=""

XUNYOU_PROC="xunyou"
FILEWALL_SHELL=""

WORK_DIR="/tmp/xunyou"
INSTALL_DIR="/tmp/.xunyou_install"
PLUGIN_CONF="${WORK_DIR}/conf/plugin.conf"
INSTALL_JSON="${INSTALL_DIR}/install.json"
INSTALL_TAR="${INSTALL_DIR}/install.tar.gz"
INSTALL_SHELL="${INSTALL_DIR}/xunyou_install.sh"

PID_FILE="/tmp/xunyou_daemon.pid"

BUILTIN="false"
IPSET_ENABLE="false"
IS_FIRST="true"

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

log()
{
    echo "${1}"

    local file_size

    if [ -f ${DAEMON_LOG} ]; then
        file_size=`ls -l ${DAEMON_LOG} | awk -F" " '{print $5}'`
    else
        file_size=0
    fi

    #如果文件大于1k，则备份为${DAEMON_LOG}.1
    if [ ${file_size} -gt 1024 ]; then
        cp -af ${DAEMON_LOG} ${DAEMON_LOG}.1
        rm -f ${DAEMON_LOG}
    fi

    echo [`date +"%Y-%m-%d %H:%M:%S"`] "${1}" >> ${DAEMON_LOG}
}

post_es_log()
{
    #local time=`date +"%Y-%m-%d %H:%M:%S"`
    local guid=`echo -n ''${LAN_IF_MAC}'merlinrouterxunyou2020!@#$' | md5sum | awk -F ' ' '{print $1}'`
    curl -s -m 20 --connect-timeout 10 --retry 3 -k -X POST -d "{\"uid\":\"0\",\"cookie_id\":\"${guid}\"}" --header "Content-type: application/json" https://ms.xunyou.com/api/statistics/public-properties >/dev/null 2>&1
    if [ $? -ne 0 ] ;then
        log "Curl post es public failed!"
    fi

    if [ "$2" == "fail" ]; then
        local error_code="N/A"
    fi

    local device_type=4
    local device_id="${guid}"

    if [ "$1" == "start" ]; then
        curl -s -m 20 --connect-timeout 10 --retry 3 -k -X POST -d "{\"uid\":\"0\", \"cookie_id\": \"${guid}\", \"device_vendors\":\"${VENDOR}\", \"device_model\":\"${MODEL}\", \"device_version\":\"${VERSION}\", \"device_type\":${device_type}, \"device_id\":\"${device_id}\", \"version_id\":\"${PLUGIN_VERSION}\", \"x_event_id\":\"r_start\", \"x_feature\":\"$2\", \"x_content\":\"${error_code}\" }" --header "Content-type: application/json" https://ms.xunyou.com/api/statistics/event >/dev/null 2>&1
        if [ $? -ne 0 ] ;then
            log "Curl post es event failed!"
        fi
    elif [ "$1" == "stop" ]; then
        curl -s -m 20 --connect-timeout 10 --retry 3 -k -X POST -d "{\"uid\":\"0\", \"cookie_id\": \"${guid}\", \"device_vendors\":\"${VENDOR}\", \"device_model\":\"${MODEL}\", \"device_version\":\"${VERSION}\", \"device_type\":${device_type}, \"device_id\":\"${device_id}\", \"version_id\":\"${PLUGIN_VERSION}\", \"x_event_id\":\"r_router_exit\", \"x_feature\":\"$2\", \"x_content\":\"${error_code}\" }" --header "Content-type: application/json" https://ms.xunyou.com/api/statistics/event >/dev/null 2>&1
        if [ $? -ne 0 ] ;then
            log "Curl post es event failed!"
        fi
    else
        return 0
    fi
}

env_init()
{
    local hostname=`uname -n`

    if [ -d "/koolshare" ]; then
        SYSTEM_TYPE="merlin"
        PLUGIN_DIR="/koolshare/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram get wps_mfstring`
        MODEL=`nvram get productid`
        VERSION=`nvram get buildno`
        DHCP_LEASES="/var/lib/misc/dnsmasq.leases"
    elif [ -d "/jffs" ]; then
        SYSTEM_TYPE="asus"
        PLUGIN_DIR="/jffs/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram get wps_mfstring`
        MODEL=`nvram get productid`
        VERSION=`nvram get buildno`
        DHCP_LEASES="/var/lib/misc/dnsmasq.leases"
    elif [ -d "/var/tmp/misc2" ]; then
        SYSTEM_TYPE="linksys"
        PLUGIN_DIR="/var/tmp/misc2/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram kget manufacturer`
        MODEL=`nvram kget modelNumber`
        VERSION=`awk -F' ' '{printf $2}' /etc/fwversion`
    elif [ -d "/etc/oray" ]; then
        SYSTEM_TYPE="oray"
        PLUGIN_DIR="/xunyou"
        LAN_IF_NAME="br-lan"
        VENDOR=`awk -F '=' '$1=="DEVICE_MANUFACTURER" {print $2}' /etc/device_info  | tr -d \'\"`
        MODEL=`awk -F '=' '$1=="DEVICE_REVISION" {print $2}' /etc/device_info  | tr -d \'\"`
        VERSION=`cat /etc/openwrt_version`
        BUILTIN="true"
    else
        local hostname=`uname -n`
        if [ "${hostname}" == "XiaoQiang" ]; then
            SYSTEM_TYPE="xiaomi"
            PLUGIN_DIR="/userdisk/appdata/2882303761520108685"
            LAN_IF_NAME="br-lan"
            VENDOR="XIAOMI"
            MODEL=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.HARDWARE`
            VERSION=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.ROM`
            BUILTIN="true"
            DHCP_LEASES="/tmp/dhcp.leases"
        elif [ "${hostname}" == "ARS2" ]; then
            SYSTEM_TYPE="koolshare"
            PLUGIN_DIR="/xunyou"
            LAN_IF_NAME="br-lan"
            VENDOR="KOOLSHARE"
            MODEL="ARS2"
            VERSION=`cat /etc/openwrt_version`
        else
            curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm | tr '\r' '\n' > /tmp/.xunyou_tmp
            if [ ! -f /tmp/.xunyou_tmp ]; then
                echo "Failed: curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm"
                return 1
            fi

            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            local version=`awk -F"=" '$1=="Firmware" {print $2}' /tmp/.xunyou_tmp`

            rm -f /tmp/.xunyou_tmp

            if [ -n ${model} -a -n ${version} ]; then
                SYSTEM_TYPE="netgear"
                LAN_IF_NAME="br0"
                VENDOR="NETGEAR"
                MODEL="${model}"
                VERSION="${version#V*}"
                BUILTIN="true"
                if [ ${MODEL:0:6} == "RAX120" ]; then
                    PLUGIN_DIR="/tmp/data/xunyou"
                else
                    PLUGIN_DIR="/data/xunyou"
                fi
            else
                echo "Unknown system type!"
                return 1
            fi
        fi
    fi

    DAEMON_LOG="${PLUGIN_DIR}/xunyou_daemon.log"
    FILEWALL_SHELL="${PLUGIN_DIR}/firewall.sh"

    PLUGIN_VERSION=`cat ${PLUGIN_DIR}/version`
    if [ -z "${PLUGIN_VERSION}" ]; then
        log "Can't find the plugin version file!"
        return 1
    fi

    LAN_IF_ADDR=`ip address show ${LAN_IF_NAME} | grep "\<inet\>" | awk -F ' ' '{print $2}' | awk -F '/' '{print $1}'`
    if [ -z "${LAN_IF_ADDR}" ]; then
        log "Can't find the lan ip!"
        return 1
    fi

    LAN_IF_MAC=`ip address show ${LAN_IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${LAN_IF_MAC}" ]; then
        log "Can't find the lan mac!"
        return 1
    fi

    CORE_TAR="${PLUGIN_DIR}/xunyou.tar.gz"
    if [ ! -e ${CORE_TAR} ]; then
        log "Can't find plugin core file ${CORE_TAR}!"
        return 1
    fi

    NOHUP_CMD=`type -p nohup`

    KERNEL=`uname -r`

    rm -f ${DAEMON_LOG}*

    log "SYSTEM_TYPE=${SYSTEM_TYPE}"

    return 0
}

create_work_dir()
{
    if [ ! -d ${WORK_DIR} ]; then
        #释放核心插件包
        tar -C ${WORK_DIR%/*} -xzf ${CORE_TAR}

        local files

        #释放lib插件包
        files=`ls ${PLUGIN_DIR}/lib*.tar.gz` >/dev/null 2>&1
        for file in ${files}; do
            tar -C ${WORK_DIR%/*} -xzf ${file}
        done

        #释放ko插件包
        files=`ls ${PLUGIN_DIR}/ko*.tar.gz` >/dev/null 2>&1
        for file in ${files}; do
            tar -C ${WORK_DIR%/*} -xzf ${file}
        done
    fi
}

delete_work_dir()
{
    rm -rf ${WORK_DIR}
}

add_module()
{
    local ko_name=$1
    local ko_path

    local ret=`lsmod 2>/dev/null | grep ${ko_name}`
    if [ -z "${ret}" ]; then
        ko_path=`find /lib/modules/${KERNEL} -name ${ko_name}.ko`
        if [ -n "${ko_path}" ]; then
            insmod ${ko_path}
        else
            if [ -d ${WORK_DIR}/modules/${KERNEL} ]; then
                ko_path=`find ${WORK_DIR}/modules/${KERNEL} -name ${ko_name}.ko`
                if [ -n "${ko_path}" ]; then
                    insmod ${ko_path}
                fi
            fi
        fi
    fi
}

#测试ipset是否支持hash:net和hash:netport，1为支持，0为不支持。
test_ipset()
{
    local cmd=`type -p ipset`
    if [ -z "${cmd}" ]; then
        return 0
    fi

    ipset -exist create xunyou_test_port bitmap:port range 0-65535 >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    ipset destroy xunyou_test_port

    ipset -exist create xunyou_test_net hash:net >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    ipset destroy xunyou_test_net

    ipset -exist create xunyou_test_netport hash:net,port >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    iptables -t nat -A PREROUTING -m set --match-set xunyou_test_netport dst -p tcp -j RETURN >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        ipset destroy xunyou_test_netport
        return 0
    fi

    iptables -t nat -D PREROUTING -m set --match-set xunyou_test_netport dst -p tcp -j RETURN
    ipset destroy xunyou_test_netport

    return 1
}

system_init()
{
    create_work_dir

    ulimit -n 2048

    add_module nf_defrag_ipv6
    add_module nf_tproxy_core
    add_module xt_TPROXY

    test_ipset
    if [ $? -eq 1 ]; then
        IPSET_ENABLE="true"
    fi

    return 0
}

download()
{
    local url="$1"
    local file="$2"
    local md5="$3"

    curl -L -s -k "$url" -o "${file}" >/dev/null 2>&1 || \
        wget -q --no-check-certificate "$url" -O "${file}" >/dev/null 2>&1 || \
        curl -s -k "$url" -o "${file}" >/dev/null 2>&1

    if [ $? -ne 0 ]; then
        log "Failed: curl (-L) -s -k ${url} -o ${file} ||
            wget -q --no-check-certificate $url -O ${file}!"
        return 1
    fi

    if [ -n "$md5" ]; then
        local download_md5=`md5sum "${file}"`
        if [ $? -ne 0 ]; then
            log "Execute md5sum failed!"
            return 1
        fi

        download_md5=`echo ${download_md5} | awk '{print $1}' | tr [a-z] [A-Z]`

        if [ "$download_md5" != "$md5" ]; then
            log "The checksum of ${file} does not match!"
            return 1
        fi
    fi

    return 0
}

download_install_json()
{
    log "vendor=${VENDOR}, model=${MODEL}, version=${VERSION}"

    local resp_info_json=`curl -s -k -X POST -H "Content-Type: application/json" -d '{"alias":"'"${VENDOR}"'","model":"'"${MODEL}"'","version":"'"${VERSION}"'"}' "https://router.xunyou.com/index.php/vendor/get-info"` > /dev/null 2>&1
    if [ $? -ne 0 ] ;then
        log "Curl get info failed!"
        return 1
    fi

    #判断网站返回的info信息是否正确
    local key="id"
    local value=`get_json_value "${resp_info_json}" "${key}"`

    if [ -z "${value}" ];then
        log "Can't find id!"
        return 1
    fi

    if [ ${value} -ne 1 ];then
        log "The id is error: ${value}!"
        return 1
    fi

    #获取install.json的下载路径
    key="url"
    value=`get_json_value "${resp_info_json}" "${key}"`
    if [ -z "${value}" ];then
        log "Can't find the install json's url!"
        return 1
    fi

    local url=`echo ${value} | sed 's/\\\\//g'`

    download ${url} ${INSTALL_JSON}
    ret=$?
    if [ ${ret} -ne 0 ]; then
        return ${ret}
    fi

    #调整install.json文件的排版格式，便于后续解析
    sed 's/,/,\n/g' -i ${INSTALL_JSON}
    sed 's/{/{\n/g' -i ${INSTALL_JSON}
    sed 's/}/\n}/g' -i ${INSTALL_JSON}
    sed 's/ //g' -i ${INSTALL_JSON}

    return 0
}

check_upgrade()
{
    download_install_json
    if [ $? -ne 0 ]; then
        log "Failed to download install json file, now skip checking upgrade."
        return 0
    fi

    #比较版本号
    local line=`grep '"version"' ${INSTALL_JSON}`
    local version=`echo ${line#*:} | tr -d '",'`

    if [ "${version}" != "${PLUGIN_VERSION}" ]; then
        return 1
    fi

    return 0
}

exec_upgrade()
{
    #小米路由器不进行自升级
    if [ "${SYSTEM_TYPE}" == "xiaomi" ]; then
        return 0
    fi

    mkdir -p ${INSTALL_DIR}

    check_upgrade
    if [ $? -eq 0 ]; then
        log "The version of plugin is latest."
        rm -rf ${INSTALL_DIR}
        return 0
    else
        log "Find new version, now begin to upgrade the plugin."

        local line=`grep '"install_url"' ${INSTALL_JSON}`
        local install_url=`echo ${line#*:} | tr -d '",'`

        line=`grep '"install_checksum"' ${INSTALL_JSON}`
        local install_md5=`echo ${line#*:} | tr -d '",'`

        rm -f ${INSTALL_JSON}

        #下载安装包
        download ${install_url} ${INSTALL_TAR} ${install_md5}
        if [ $? -ne 0 ]; then
            log "Failed to download ${INSTALL_TAR}."
            return 1
        fi

        #解压缩安装包
        tar -C ${INSTALL_DIR} -xzf ${INSTALL_TAR}

        #执行安装更新程序
        sh ${INSTALL_SHELL} upgrade &

        exit
    fi

    return 0
}

check_firewall()
{
    ${FILEWALL_SHELL} status >> ${DAEMON_LOG}
    if [ $? -ne 0 ]; then
        return 1
    fi

    return 0
}

close_firewall()
{
    ${FILEWALL_SHELL} close

    if [ ${IPSET_ENABLE} == "true" ]; then
        ipset destroy xunyou_black_net_port >/dev/null 2>&1
        ipset destroy xunyou_grey_net_port >/dev/null 2>&1
        ipset destroy xunyou_white_net_port >/dev/null 2>&1

        ipset destroy xunyou_black_tcp_net >/dev/null 2>&1
        ipset destroy xunyou_grey_tcp_net >/dev/null 2>&1
        ipset destroy xunyou_white_tcp_net >/dev/null 2>&1

        ipset destroy xunyou_black_udp_net >/dev/null 2>&1
        ipset destroy xunyou_grey_udp_net >/dev/null 2>&1
        ipset destroy xunyou_white_udp_net >/dev/null 2>&1

        ipset destroy xunyou_black_tcp_port >/dev/null 2>&1
        ipset destroy xunyou_grey_tcp_port >/dev/null 2>&1
        ipset destroy xunyou_white_tcp_port >/dev/null 2>&1

        ipset destroy xunyou_black_udp_port >/dev/null 2>&1
        ipset destroy xunyou_grey_udp_port >/dev/null 2>&1
        ipset destroy xunyou_white_udp_port >/dev/null 2>&1
    fi

    return 0
}

open_firewall()
{
    ${FILEWALL_SHELL} open

    return 0
}

clear_conf()
{
    rm -f ${PLUGIN_CONF}
    return 0
}

config_conf()
{
    echo "{" > ${PLUGIN_CONF}
    echo "    \"pluginVer\":\"${PLUGIN_VERSION}\"," >> ${PLUGIN_CONF}
    echo "    \"systemType\":\"${SYSTEM_TYPE}\"," >> ${PLUGIN_CONF}
    echo "    \"builtIn\":${BUILTIN}," >> ${PLUGIN_CONF}
    echo "    \"ipsetEnable\":${IPSET_ENABLE}," >> ${PLUGIN_CONF}
    echo "    \"lanIf\":\"${LAN_IF_NAME}\"," >> ${PLUGIN_CONF}
    echo "    \"lanIp\":\"${LAN_IF_ADDR}\"," >> ${PLUGIN_CONF}
    echo "    \"lanMac\":\"${LAN_IF_MAC}\"," >> ${PLUGIN_CONF}
    echo "    \"routerVendor\":\"${VENDOR}\"," >> ${PLUGIN_CONF}
    echo "    \"routerModel\":\"${MODEL}\"," >> ${PLUGIN_CONF}
    echo "    \"routerVer\":\"${VERSION}\"," >> ${PLUGIN_CONF}
    echo "    \"dhcpLeases\":\"${DHCP_LEASES}\"," >> ${PLUGIN_CONF}
    echo "}" >> ${PLUGIN_CONF}

    return 0
}

#检查进程状态，正常返回0，否则返回1
check_process()
{
    local pid=`ps -w | grep ${WORK_DIR}/bin/${XUNYOU_PROC} | grep -v grep | awk -F" " '{print $1}'`
    if [ -z "${pid}" ]; then
        log "${XUNYOU_PROC} process is not running!"
        if [ "${IS_FIRST}" == "true" ]; then
            post_es_log start fail
            IS_FIRST="false"
        fi
        return 1
    fi

    if [ "${IS_FIRST}" == "true" ]; then
        post_es_log start success
        IS_FIRST="false"
    fi

    return 0
}

start_process()
{
    if [ "${SYSTEM_TYPE}" == "merlin" -o "${SYSTEM_TYPE}" == "asus" ]; then
        echo 1 > /proc/sys/vm/overcommit_memory
    fi

    export LD_LIBRARY_PATH=${WORK_DIR}/lib:${LD_LIBRARY_PATH}

    mkdir -p ${PLUGIN_DIR}/.cache

    ${NOHUP_CMD} ${WORK_DIR}/bin/${XUNYOU_PROC} -c ${PLUGIN_CONF} >/dev/null 2>&1 &

    local library_path=`echo ${LD_LIBRARY_PATH} | sed "s#${WORK_DIR}/lib:##g"`
    export LD_LIBRARY_PATH=${library_path}
    if [ -f /sys/fs/cgroup/plugin/cgroup.procs ]; then
        local pid=`ps -w | grep ${WORK_DIR}/bin/${XUNYOU_PROC} | grep -v grep | awk -F" " '{print $1}'`
        echo "$pid" > /sys/fs/cgroup/plugin/cgroup.procs
    fi

    return 0
}

stop_process()
{
    killall ${XUNYOU_PROC} >/dev/null 2>&1
    killall `basename ${FILEWALL_SHELL}` >/dev/null 2>&1
    rm -f /tmp/xunyou_*_fd

    return 0
}

start_plugin()
{
    create_work_dir
    config_conf
    open_firewall
    start_process
}

stop_plugin()
{
    stop_process
    close_firewall
    clear_conf
    delete_work_dir
    post_es_log stop success
}

restart_plugin()
{
    stop_plugin
    start_plugin
}

restart_plugin_with_upgrade()
{
    stop_plugin
    exec_upgrade
    start_plugin
}

config_plugin()
{
    create_work_dir
    config_conf
    open_firewall
    post_es_log start success
}

#检查守护进程状态，0为正常，否则返回1
check_deamon()
{
    if [ -f ${PID_FILE} ]; then
        local deamon_pid=`cat ${PID_FILE}`
        local pid_list

        if [ ${SYSTEM_TYPE} == "merlin" ]; then
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '{print $1}'`
        else
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '{print $1}'`
        fi

        for pid in `echo ${pid_list}`
        do
            if [ "${pid}" == "${deamon_pid}" ]; then
                return 0
            fi
        done
    fi

    return 1
}

start_daemon()
{
    local self=$$
    local pid_list

    if [ ${SYSTEM_TYPE} == "merlin" ]; then
        pid_list=`sh -c 'subpid=$$;ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '"'"'$1!=$subpid {print $1}'"'"`
    else
        pid_list=`sh -c 'subpid=$$;ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '"'"'$1!=$subpid {print $1}'"'"`
    fi

    for pid in `echo ${pid_list}`
    do
        if [ "${pid}" != "${self}" ]; then
            if [ -f /sys/fs/cgroup/plugin/cgroup.procs ]; then
                echo "${pid}" > /sys/fs/cgroup/plugin/cgroup.procs
            fi
            echo "${pid}" > ${PID_FILE}
            break
        fi
    done

    while [ 1 ]
    do
        sleep 60

        check_process
        if [ $? -ne 0 ]; then
            IS_FIRST="true"
            restart_plugin
        fi

        check_firewall
        if [ $? -ne 0 ]; then
            IS_FIRST="true"
            restart_plugin
        fi
    done
}

stop_daemon()
{
    if [ -f ${PID_FILE} ]; then
        local deamon_pid=`cat ${PID_FILE}`
        local pid_list

        if [ ${SYSTEM_TYPE} == "merlin" ]; then
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '{print $1}'`
        else
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '{print $1}'`
        fi

        for pid in `echo ${pid_list}`
        do
            if [ "${pid}" == "${deamon_pid}" ]; then
                kill -9 ${pid} >/dev/null 2>&1
                break
            fi
        done

        rm -f ${PID_FILE}
    fi
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

system_init

case ${ACTION} in
    "start")
        log "[start]: 启动迅游插件！"
        if [ "${VENDOR}" == "XIAOMI" ]; then
            mode=`uci -q get xiaoqiang.common.NETMODE`
            if [ "$mode" == "wifiapmode" -o "$mode" == "lanapmode" ]; then
                echo "xunyou: no run in AP mode"
                            echo "[stop] .................."
                            stop_daemon
                            stop_plugin
                exit 1
            fi
        fi
        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin_with_upgrade
            start_daemon &
        fi
        ;;

    "check")
        log "[check]: 启动迅游插件！"

        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin_with_upgrade
            start_daemon &
        fi
        ;;

    "stop")
        log "[stop] 停止迅游插件"

        stop_daemon
        stop_plugin
        ;;

    "restart")
        log "[restart]: 重新启动迅游模块！"
        if [ "${VENDOR}" == "XIAOMI" ]; then
            mode=`uci -q get xiaoqiang.common.NETMODE`
            if [ "$mode" == "wifiapmode" -o "$mode" == "lanapmode" ]; then
                echo "xunyou: no run in AP mode"
                            echo "[stop] .................."
                            stop_daemon
                            stop_plugin
                exit 1
            fi
        fi
        stop_daemon
        restart_plugin_with_upgrade
        start_daemon &
        ;;

    "app")
        log "[app]: 重新启动迅游模块！"

        stop_daemon
        restart_plugin_with_upgrade
        start_daemon &
        ;;

    "simple")
        log "[simple]: 启动迅游模块！"
        if [ "${VENDOR}" == "XIAOMI" ]; then
            mode=`uci -q get xiaoqiang.common.NETMODE`
            if [ "$mode" == "wifiapmode" -o "$mode" == "lanapmode" ]; then
                echo "xunyou: no run in AP mode"
                            echo "[stop] .................."
                            stop_daemon
                            stop_plugin
                exit 1
            fi
        fi
        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin
            start_daemon &
        fi
        ;;

    "status")
        log "[status]: 查询迅游模块状态！"

        check_deamon
        if [ $? -ne 0 ]; then
            log "Daemon is not running."
            exit 1
        fi

        check_process
        if [ $? -ne 0 ]; then
            exit 1
        fi

        check_firewall
        if [ $? -ne 0 ]; then
            exit 1
        fi

        exit 0
        ;;

    "config")
        log "[config]: 仅配置迅游插件，不启动进程！"

        stop_daemon
        stop_plugin
        config_plugin

        exit 0
        ;;

    *)
        http_response "$1"

        if [ "${xunyou_enable}" == "1" ]; then
            log "[default]: 启动迅游插件！"

            stop_daemon
            restart_plugin_with_upgrade
            start_daemon &
        else
            log "[default] 停止迅游插件"

            stop_daemon
            stop_plugin
        fi
        ;;
esac

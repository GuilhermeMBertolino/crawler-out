#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

ACTION=$1

SYSTEM_TYPE=""
PLUGIN_DIR=""
IF_NAME=""
IF_MAC=""
MODEL=""

WORK_DIR="/tmp/xunyou"

POST_PROC="xunyou_post"

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

env_init()
{
    local hostname=`uname -n`

    if [ -d "/koolshare" ]; then
        SYSTEM_TYPE="merlin"
        PLUGIN_DIR="/koolshare/xunyou"
        IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/jffs" ]; then
        SYSTEM_TYPE="asus"
        PLUGIN_DIR="/jffs/xunyou"
        IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/var/tmp/misc2" ]; then
        SYSTEM_TYPE="linksys"
        PLUGIN_DIR="/var/tmp/misc2/xunyou"
        IF_NAME="br0"
        MODEL=`nvram kget modelNumber`
    elif [ -d "/etc/oray" ]; then
        SYSTEM_TYPE="oray"
        PLUGIN_DIR="/xunyou"
        IF_NAME="br-lan"
        MODEL=`cat /etc/device_info | grep DEVICE_REVISION |awk -F '"' '{print $2}'`
    else
        local hostname=`uname -n`
        if [ "${hostname}" == "XiaoQiang" ]; then
            SYSTEM_TYPE="xiaomi"
            PLUGIN_DIR="/userdisk/appdata/2882303761520108685"
            IF_NAME="br-lan"
            MODEL=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.HARDWARE`
        elif [ "${hostname}" == "ARS2" ]; then
            SYSTEM_TYPE="koolshare"
            PLUGIN_DIR="/xunyou"
            IF_NAME="eth1"
            MODEL="ARS2"
        else
            curl -s http://127.0.0.1/currentsetting.htm | tr '\r' '\n' > /tmp/.xunyou_tmp
            if [ ! -f /tmp/.xunyou_tmp ]; then
                echo "Failed: curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm"
                return 1
            fi

            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            local version=`awk -F"=" '$1=="Firmware" {print $2}' /tmp/.xunyou_tmp`

            rm -f /tmp/.xunyou_tmp

            if [ -n ${model} -a -n ${version} ]; then
                SYSTEM_TYPE="netgear"
                IF_NAME="br0"
                MODEL="${model}"
                if [ ${MODEL:0:6} == "RAX120" ]; then
                    PLUGIN_DIR="/tmp/data/xunyou"
                else
                    PLUGIN_DIR="/data/xunyou"
                fi
            else
                echo "Unknown system type!"
                return 1
            fi
        fi
    fi

    IF_MAC=`ip address show ${IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${IF_MAC}" ]; then
        echo "Can't find the lan mac!"
        return 1
    fi

    return 0
}

stop_plugin()
{
    sh ${PLUGIN_DIR}/xunyou_daemon.sh stop
}

delete_plugin()
{
    if [ "${SYSTEM_TYPE}" == "merlin" ]; then
        rm -f /koolshare/webs/Module_xunyou.asp
        rm -f /koolshare/res/icon-xunyou.png
        rm -f /koolshare/scripts/uninstall_xunyou.sh /koolshare/scripts/xunyou*.sh
        rm -f /koolshare/init.d/S90XunYouAcc.sh

        local values=`dbus list xunyou_ | cut -d "=" -f 1`
        for value in ${values}
        do
            dbus remove ${value}
        done

        values=`dbus list softcenter_module_xunyou_ | cut -d "=" -f 1`
        for value in ${values}
        do
            dbus remove ${value}
        done
    fi

    rm -rf ${WORK_DIR} ${PLUGIN_DIR}
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

stop_plugin

delete_plugin

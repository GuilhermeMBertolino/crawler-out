#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

SYSTEM_TYPE=""
LAN_IF_NAME=""
LAN_IF_ADDR=""

FIREWALL_LOG=""

DEFAULT_BRIDGE_VALUE=0
BRIDGE_VALUE=""
MARK=""
MODEL=""
WORK_DIR="/tmp/xunyou"
XUNYOU_CHAIN="XUNYOU"
XUNYOU_ACC_CHAIN="XUNYOU_ACC"
XUNYOU_PROXY_CHAIN="XUNYOU_PROXY"
XUNYOU_CDN_CHAIN="XUNYOU_CDN"
TABLE_ID="95"
PROXY_PORT=9800
ACC_CONF="${WORK_DIR}/conf/accelerate"

PLUGIN_DOMAIN_HEX="|06|plugin|06|xunyou|03|com"
OLD_PLUGIN_DOMAIN_HEX="|0a|router-lan|10|xyrouterqpm3v2bi|02|cc"

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

env_init()
{
    local hostname=`uname -n`

    if [ -d "/koolshare" ]; then
        SYSTEM_TYPE="merlin"
        LAN_IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/jffs" ]; then
        SYSTEM_TYPE="asus"
        LAN_IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/var/tmp/misc2" ]; then
        SYSTEM_TYPE="linksys"
        LAN_IF_NAME="br0"
        MODEL=`nvram kget modelNumber`
    elif [ -d "/etc/oray" ]; then
        SYSTEM_TYPE="oray"
        LAN_IF_NAME="br-lan"
        MODEL=`awk -F '=' '$1=="DEVICE_REVISION" {print $2}' /etc/device_info  | tr -d \'\"`
    else
        local hostname=`uname -n`
        if [ "${hostname}" == "XiaoQiang" ]; then
            SYSTEM_TYPE="xiaomi"
            LAN_IF_NAME="br-lan"
            MODEL=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.HARDWARE`
        elif [ "${hostname}" == "ARS2" ]; then
            SYSTEM_TYPE="koolshare"
            LAN_IF_NAME="br-lan"
            MODEL="ARS2"
        else
            curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm | tr '\r' '\n' > /tmp/.xunyou_tmp
            if [ ! -f /tmp/.xunyou_tmp ]; then
                echo "Failed: curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm"
                return 1
            fi

            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            local version=`awk -F"=" '$1=="Firmware" {print $2}' /tmp/.xunyou_tmp`
            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            
            rm -f /tmp/.xunyou_tmp

            if [ -n ${model} -a -n ${version} ]; then
                SYSTEM_TYPE="netgear"
                LAN_IF_NAME="br0"
                MODEL="${model}"
            else
                echo "Unknown system type!"
                return 1
            fi
        fi
    fi

    LAN_IF_ADDR=`ip address show ${LAN_IF_NAME} | grep "\<inet\>" | awk -F ' ' '{print $2}' | awk -F '/' '{print $1}'`
    if [ -z "${LAN_IF_ADDR}" ]; then
        echo "Can't find the lan ip!"
        return 1
    fi

    LAN_IF_MAC=`ip address show ${LAN_IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${LAN_IF_MAC}" ]; then
        echo "Can't find the lan mac!"
        return 1
    fi
    
    if [ ${MODEL} == "RB05" ]; then
        MARK="0x40/0xc0"
    else
        MARK="0x20/0x20"
    fi
    if [ "${SYSTEM_TYPE}" == "xiaomi" ]; then
        if [ ${MODEL} == "RB04" -o ${MODEL} == "RB08" ]; then
            DEFAULT_BRIDGE_VALUE=1
        fi
        
        if [ ${MODEL} == "RB05" -o ${MODEL} == "RB06" -o ${MODEL} == "RA72" ]; then
            DEFAULT_BRIDGE_VALUE=0
        fi
    fi
    return 0
}

check_rule()
{
    iptables -t mangle -n -L ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "Mangle chain ${XUNYOU_CHAIN} hasn't been configurated!"
        return 1
    fi

    iptables -t mangle -n -L ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "Mangle chain ${XUNYOU_ACC_CHAIN} hasn't been configurated!"
        return 1
    fi

    iptables -t mangle -C PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "Mangle rule hasn't been configurated in chain PREROUTING"
        return 1
    fi

    iptables -t nat -n -L ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "Nat chain ${XUNYOU_CHAIN} hasn't been configurated!"
        return 1
    fi

    iptables -t nat -n -L ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "Nat chain ${XUNYOU_ACC_CHAIN} hasn't been configurated!"
        return 1
    fi

    iptables -t nat -C PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "Nat rule hasn't been configurated in chain PREROUTING"
        return 1
    fi

    return 0
}

config_acc_rule()
{
    local src_ip=$1
    local support_ipset

    #如果set不存在，则认为不支持ipset
    ipset list xunyou_black_net_port >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        support_ipset="true"
    else
        support_ipset="false"
    fi

    #记录下相关的规则，便于快速恢复配置
    echo "ip route add local default dev lo table ${TABLE_ID}" > ${ACC_CONF}
    ip route add local default dev lo table ${TABLE_ID}

    echo "ip rule add fwmark ${MARK} table ${TABLE_ID}" >> ${ACC_CONF}
    ip rule add fwmark ${MARK} table ${TABLE_ID}

    echo "iptables -t mangle -N ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
    iptables -t mangle -N ${XUNYOU_PROXY_CHAIN}

    echo "iptables -t mangle -I ${XUNYOU_PROXY_CHAIN} -j CONNMARK --set-xmark ${MARK}" >> ${ACC_CONF}
    iptables -t mangle -I ${XUNYOU_PROXY_CHAIN} -j CONNMARK --set-xmark ${MARK}

    echo "iptables -t mangle -A ${XUNYOU_PROXY_CHAIN} -p udp -j TPROXY --on-ip 127.0.0.1 --on-port ${PROXY_PORT} --tproxy-mark ${MARK}" >> ${ACC_CONF}
    iptables -t mangle -A ${XUNYOU_PROXY_CHAIN} -p udp -j TPROXY --on-ip 127.0.0.1 --on-port ${PROXY_PORT} --tproxy-mark ${MARK}

    echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p udp --dport 53 -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
    iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p udp --dport 53 -j ${XUNYOU_PROXY_CHAIN}

    if [ ${support_ipset} == "true" ]; then
        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_udp_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_udp_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_net_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_net_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_udp_net dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_udp_net dst -p udp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_udp_port dst -p udp -j RETURN" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_udp_port dst -p udp -j RETURN

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_net_port dst -p udp -j RETURN" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_net_port dst -p udp -j RETURN

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_udp_net dst -p udp -j RETURN" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_udp_net dst -p udp -j RETURN

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_udp_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_udp_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_net_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_net_port dst -p udp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_udp_net dst -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_udp_net dst -p udp -j ${XUNYOU_PROXY_CHAIN}
    else
        echo "iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p udp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t mangle -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p udp -j ${XUNYOU_PROXY_CHAIN}
    fi

    echo "iptables -t nat -N ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
    iptables -t nat -N ${XUNYOU_PROXY_CHAIN}

    echo "iptables -t nat -I ${XUNYOU_PROXY_CHAIN} -j CONNMARK --set-xmark ${MARK}" >> ${ACC_CONF}
    iptables -t nat -I ${XUNYOU_PROXY_CHAIN} -j CONNMARK --set-xmark ${MARK}

    echo "iptables -t nat -A ${XUNYOU_PROXY_CHAIN} -p tcp -j REDIRECT --to-ports ${PROXY_PORT}" >> ${ACC_CONF}
    iptables -t nat -A ${XUNYOU_PROXY_CHAIN} -p tcp -j REDIRECT --to-ports ${PROXY_PORT}

    if [ ${support_ipset} == "true" ]; then
        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_tcp_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_tcp_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_net_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_net_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_tcp_net dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_black_tcp_net dst -p tcp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_tcp_port dst -p tcp -j RETURN" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_tcp_port dst -p tcp -j RETURN

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_net_port dst -p tcp -j RETURN" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_net_port dst -p tcp -j RETURN

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_tcp_net dst -p tcp -j RETURN" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_grey_tcp_net dst -p tcp -j RETURN

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_tcp_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_tcp_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_net_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_net_port dst -p tcp -j ${XUNYOU_PROXY_CHAIN}

        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_tcp_net dst -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -m set --match-set xunyou_white_tcp_net dst -p tcp -j ${XUNYOU_PROXY_CHAIN}
    else
        echo "iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p tcp -j ${XUNYOU_PROXY_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_ACC_CHAIN} -s ${src_ip} -p tcp -j ${XUNYOU_PROXY_CHAIN}
    fi

    if [ "${SYSTEM_TYPE}" == "xiaomi" ]; then
        BRIDGE_VALUE=`sysctl -n net.bridge.bridge-nf-call-iptables`
        if [ "${BRIDGE_VALUE}" == "1" ]; then
            echo "sysctl -w net.bridge.bridge-nf-call-iptables=0" >> ${ACC_CONF}
            sysctl -w net.bridge.bridge-nf-call-iptables=0
        fi
    fi
}

config_cdn_rule()
{
    local src_ip=$1
    local dst_ip=$2
    local dst_port=$3
    local redirect_port=$4

    #记录下相关的规则，便于快速恢复配置
    iptables -t nat -n -L ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "iptables -t nat -N ${XUNYOU_CDN_CHAIN}" >> ${ACC_CONF}
        iptables -t nat -N ${XUNYOU_CDN_CHAIN}

        echo "iptables -t nat -I ${XUNYOU_CDN_CHAIN} -j CONNMARK --set-xmark ${MARK}" >> ${ACC_CONF}
        iptables -t nat -I ${XUNYOU_CDN_CHAIN} -j CONNMARK --set-xmark ${MARK}
    fi

    iptables -t nat -C ${XUNYOU_CDN_CHAIN} -p tcp --dport ${dst_port} -j REDIRECT --to-ports ${redirect_port}
    if [ $? -ne 0 ]; then
        echo "iptables -t nat -A ${XUNYOU_CDN_CHAIN} -p tcp --dport ${dst_port} -j REDIRECT --to-ports ${redirect_port}" >> ${ACC_CONF}
        iptables -t nat -A ${XUNYOU_CDN_CHAIN} -p tcp --dport ${dst_port} -j REDIRECT --to-ports ${redirect_port}
    fi

    echo "iptables -t nat -I ${XUNYOU_ACC_CHAIN} -s ${src_ip} -d ${dst_ip} -p tcp --dport ${dst_port} -j ${XUNYOU_CDN_CHAIN}" >> ${ACC_CONF}
    iptables -t nat -I ${XUNYOU_ACC_CHAIN} -s ${src_ip} -d ${dst_ip} -p tcp --dport ${dst_port} -j ${XUNYOU_CDN_CHAIN}
}

clear_acc_rule()
{
    if [ "${SYSTEM_TYPE}" == "xiaomi" ]; then
        sysctl -w net.bridge.bridge-nf-call-iptables=$DEFAULT_BRIDGE_VALUE >/dev/null 2>&1
    fi

    iptables -t mangle -F ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1
    iptables -t mangle -F ${XUNYOU_PROXY_CHAIN} >/dev/null 2>&1
    iptables -t mangle -X ${XUNYOU_PROXY_CHAIN} >/dev/null 2>&1

    iptables -t nat -F ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1
    iptables -t nat -F ${XUNYOU_PROXY_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_PROXY_CHAIN} >/dev/null 2>&1

    iptables -t nat -F ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_CDN_CHAIN} >/dev/null 2>&1

    ip rule del table ${TABLE_ID} >/dev/null 2>&1
    ip route flush table ${TABLE_ID} >/dev/null 2>&1

    rm -f ${ACC_CONF}
}

clear_rule()
{
    clear_acc_rule

    iptables -t mangle -F ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t mangle -D PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t mangle -X ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t mangle -X ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1

    iptables -t nat -F ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t nat -D PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_CHAIN} >/dev/null 2>&1
    iptables -t nat -X ${XUNYOU_ACC_CHAIN} >/dev/null 2>&1

    return 0
}

init_rule()
{
    #查看work目录是否存在，如果不存在则说明插件未启动，不用进行后续配置
    if [ -d ${WORK_DIR} ]; then
        #添加mangle表规则
        iptables -t mangle -N ${XUNYOU_CHAIN}
        iptables -t mangle -N ${XUNYOU_ACC_CHAIN}
        iptables -t mangle -I PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN}
        iptables -t mangle -F ${XUNYOU_CHAIN}

        #查询插件域名的DNS报文直接ACCEPT，交给NAT表处理
        iptables -t mangle -A ${XUNYOU_CHAIN} -p udp --dport 53 -m string --hex-string "${PLUGIN_DOMAIN_HEX}" --algo kmp -j ACCEPT
        iptables -t mangle -A ${XUNYOU_CHAIN} -p udp --dport 53 -m string --hex-string "${OLD_PLUGIN_DOMAIN_HEX}" --algo kmp -j ACCEPT

        #从lan口上来，发送给路由器的报文，如果是DNS报文，则优先匹配XUNYOU_ACC_CHAIN链；否则不做处理
        iptables -t mangle -A ${XUNYOU_CHAIN} -d ${LAN_IF_ADDR} -p udp --dport 53 -j ${XUNYOU_ACC_CHAIN}
        iptables -t mangle -A ${XUNYOU_CHAIN} -d ${LAN_IF_ADDR} -j RETURN
        iptables -t mangle -A ${XUNYOU_CHAIN} -p udp -j ${XUNYOU_ACC_CHAIN}

        #添加nat表规则
        iptables -t nat -N ${XUNYOU_CHAIN}
        iptables -t nat -N ${XUNYOU_ACC_CHAIN}
        iptables -t nat -I PREROUTING -i ${LAN_IF_NAME} -j ${XUNYOU_CHAIN}
        iptables -t nat -F ${XUNYOU_CHAIN}

        #从lan口上来，发送给路由器的报文，因为DNS报文已经在mangle表中处理了，所以这里所有报文都不做特殊处理
        iptables -t nat -A ${XUNYOU_CHAIN} -d ${LAN_IF_ADDR} -j RETURN

        #查询插件域名的DNS报文转给本地DNS服务程序处理
        iptables -t nat -A ${XUNYOU_CHAIN} -p udp --dport 53 -m string --hex-string "${PLUGIN_DOMAIN_HEX}" --algo kmp -j REDIRECT --to-ports 53
        iptables -t nat -A ${XUNYOU_CHAIN} -p udp --dport 53 -m string --hex-string "${OLD_PLUGIN_DOMAIN_HEX}" --algo kmp -j REDIRECT --to-ports 53

        iptables -t nat -A ${XUNYOU_CHAIN} -p tcp -j ${XUNYOU_ACC_CHAIN}
    fi

    return 0
}

#called by fw3 framework
reload_fw() {
    #将ACC_CONF文件改名，防止清除规则的时候该文件被删除
    if [ -f ${ACC_CONF} ]; then
        mv ${ACC_CONF} ${ACC_CONF}.tmp
    fi

    clear_rule
    init_rule

    if [ -f ${ACC_CONF}.tmp ]; then
        mv ${ACC_CONF}.tmp ${ACC_CONF}

        while read line
        do
            $line
        done < ${ACC_CONF}
    fi
}

#called by plugin-app
open_fw(){
    init_rule
}

#called by plugin-app
close_fw(){
    clear_rule
}

#called by plugin-app
check_fw(){
    check_rule
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

case $1 in
    "reload")
        reload_fw
        ;;
    "open")
        open_fw
        ;;
    "close")
        close_fw
        ;;
    "status")
        check_fw
        if [ $? -ne 0 ]; then
            exit 1
        fi
        ;;
    "start_acc")
        config_acc_rule $2
        ;;
    "stop_acc")
        clear_acc_rule
        ;;
    "config_cdn")
        config_cdn_rule $2 $3 $4 $5
        ;;
    *)
    #others
    ;;
esac

exit 0
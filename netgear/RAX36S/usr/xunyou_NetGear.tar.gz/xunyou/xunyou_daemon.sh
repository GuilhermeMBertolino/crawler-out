#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

ACTION=$1

SYSTEM_TYPE=""
PLUGIN_DIR=""
LAN_IF_NAME=""
VENDOR=""
MODEL=""
VERSION=""
PLUGIN_VERSION=""
LAN_IF_ADDR=""
LAN_IF_MAC=""
KERNEL=""
DHCP_LEASES=""

BIND_INFO=""
DEVICE_INFO=""
RECORD_INFO=""
UPGRADE_SHELL=""
ACCELERALTE_SHELL=""
DAEMON_LOG=""
CTRL_LOG=""
PROXY_LOG=""
IPSET_LOG=""
CORE_TAR=""
USER_NAME=""
NOHUP_CMD=""

CTRL_PROC="xunyou_ctrl"
PROXY_PROC="xunyou_proxy"
POST_PROC="xunyou_post"
FILEWALL_SHELL=""

WORK_DIR="/tmp/xunyou"
INSTALL_DIR="/tmp/.xunyou_install"
PLUGIN_CONF="${WORK_DIR}/conf/plugin.conf"
INSTALL_JSON="${INSTALL_DIR}/install.json"
INSTALL_TAR_URL="https://partnerdownload.xunyou.com/routeplugin/install.tar.gz"
INSTALL_TAR="${INSTALL_DIR}/install.tar.gz"
INSTALL_SHELL="${INSTALL_DIR}/xunyou_install.sh"

PID_FILE="/tmp/xunyou_daemon.pid"

BUILTIN="false"
SUPPORT_IPSET="false"
SUPPORT_PLUGIN_DOMAIN="false"

PLUGIN_DOMAIN="plugin.xunyou.com"
PLUGIN_DOMAIN_HEX="|06|plugin|06|xunyou|03|com"
OLD_PLUGIN_DOMAIN="router-lan.xyrouterqpm3v2bi.cc"
OLD_PLUGIN_DOMAIN_HEX="|0a|router-lan|10|xyrouterqpm3v2bi|02|cc"

PUBLIC_IP=""

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

log()
{
    echo "${1}"

    local file_size

    if [ -f ${DAEMON_LOG} ]; then
        file_size=`ls -l ${DAEMON_LOG} | awk -F" " '{print $5}'`
    else
        file_size=0
    fi

    #如果文件大于1k，则备份为${DAEMON_LOG}.1
    if [ ${file_size} -gt 1024 ]; then
        cp -af ${DAEMON_LOG} ${DAEMON_LOG}.1
        rm -f ${DAEMON_LOG}
    fi

    echo [`date +"%Y-%m-%d %H:%M:%S"`] "${1}" >> ${DAEMON_LOG}
}

post_log()
{
    [ ! -e ${WORK_DIR}/bin/${POST_PROC} ] && return 0

    local action=$1
    local tmp_file="/tmp/.xunyou_post.log"
    local time=`date +"%Y-%m-%d %H:%M:%S"`
    local guid=`echo -n ''${LAN_IF_MAC}'merlinrouterxunyou2020!@#$' | md5sum | awk -F ' ' '{print $1}'`
    local data

    if [ "${action}" == "start" ]; then
        local start_status=0

        local ctrl_pid=`ps -w | grep ${CTRL_PROC} | grep -v grep | awk -F" " '{print $1}'`
        local proxy_pid=`ps -w | grep ${PROXY_PROC} | grep -v grep | awk -F" " '{print $1}'`

        if [ -n "${ctrl_pid}" -a -n "${proxy_pid}" ]; then
            start_status=1
        fi

        data='{"id":1003,"user":"${USER_NAME}","mac":"'${LAN_IF_MAC}'","data":{"type":6,"account":"${USER_NAME}","model":"'${MODEL}'","guid":"'${guid}'","mac":"'${LAN_IF_MAC}'","publicIp":"'${PUBLIC_IP}'","source":0,"success":'${start_status}',"reporttime":"'${time}'"}}'
    elif [ "${action}" == "stop" ]; then
        data='{"id":1003,"user":"${USER_NAME}","mac":"'${LAN_IF_MAC}'","data":{"type":9,"account":"${USER_NAME}","model":"'${MODEL}'","guid":"'${guid}'","mac":"'${LAN_IF_MAC}'","publicIp":"'${PUBLIC_IP}'","source":0,"reporttime":"'${time}'"}}'
    elif [ "${action}" == "crash" ]; then
        local proc=$2

        data='{"id":1003,"user":"${USER_NAME}","mac":"'${LAN_IF_MAC}'","data":{"type":5,"account":"${USER_NAME}","model":"'${MODEL}'","guid":"'${guid}'","mac":"'${LAN_IF_MAC}'","publicIp":"'${PUBLIC_IP}'","crashdll":"'${proc}'","reporttime":"'${time}'"}}'
    else
        return 0
    fi

    echo ${data} > ${tmp_file}

    ${WORK_DIR}/bin/${POST_PROC} -d "acceldata.xunyou.com" -p 9240 -f ${tmp_file} >/dev/null 2>&1

    rm -f ${tmp_file}
}

env_init()
{
    local hostname=`uname -n`

    if [ -d "/koolshare" ]; then
        SYSTEM_TYPE="merlin"
        PLUGIN_DIR="/koolshare/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram get wps_mfstring`
        MODEL=`nvram get productid`
        VERSION=`nvram get buildno`
        DHCP_LEASES="/var/lib/misc/dnsmasq.leases"
    elif [ -d "/jffs" ]; then
        SYSTEM_TYPE="asus"
        PLUGIN_DIR="/jffs/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram get wps_mfstring`
        MODEL=`nvram get productid`
        VERSION=`nvram get buildno`
        DHCP_LEASES="/var/lib/misc/dnsmasq.leases"
    elif [ -d "/var/tmp/misc2" ]; then
        SYSTEM_TYPE="linksys"
        PLUGIN_DIR="/var/tmp/misc2/xunyou"
        LAN_IF_NAME="br0"
        VENDOR=`nvram kget manufacturer`
        MODEL=`nvram kget modelNumber`
        VERSION=`awk -F' ' '{printf $2}' /etc/fwversion`
    elif [ -d "/etc/oray" ]; then
        SYSTEM_TYPE="oray"
        PLUGIN_DIR="/xunyou"
        LAN_IF_NAME="br-lan"
        VENDOR=`cat /etc/device_info | grep DEVICE_MANUFACTURER |awk -F '"' '{print $2}'`
        MODEL=`cat /etc/device_info | grep DEVICE_REVISION |awk -F '"' '{print $2}'`
        VERSION=`cat /etc/openwrt_version`
    else
        local hostname=`uname -n`
        if [ "${hostname}" == "XiaoQiang" ]; then
            SYSTEM_TYPE="xiaomi"
            PLUGIN_DIR="/userdisk/appdata/2882303761520108685"
            LAN_IF_NAME="br-lan"
            VENDOR="XIAOMI"
            MODEL=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.HARDWARE`
            VERSION=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.ROM`
            BUILTIN="true"
            DHCP_LEASES="/tmp/dhcp.leases"
        elif [ "${hostname}" == "ARS2" ]; then
            SYSTEM_TYPE="koolshare"
            PLUGIN_DIR="/xunyou"
            LAN_IF_NAME="eth1"
            VENDOR="KOOLSHARE"
            MODEL="ARS2"
            VERSION=`cat /etc/openwrt_version`
        else
            curl -s --connect-timeout 3 --retry 3 http://127.0.0.1/currentsetting.htm | tr '\r' '\n' > /tmp/.xunyou_tmp
            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            local version=`awk -F"=" '$1=="Firmware" {print $2}' /tmp/.xunyou_tmp`

            rm -f /tmp/.xunyou_tmp

            if [ -n ${model} -a -n ${version} ]; then
                SYSTEM_TYPE="netgear"
                PLUGIN_DIR="/data/xunyou"
                LAN_IF_NAME="br0"
                VENDOR="NETGEAR"
                MODEL="${model}"
                VERSION="${version#V*}"
                BUILTIN="true"
            else
                echo "Unknown system type!"
                return 1
            fi
        fi
    fi

    PLUGIN_CONF="${WORK_DIR}/conf/plugin.conf"
    BIND_INFO="${PLUGIN_DIR}/.cache/bind_info"
    DEVICE_INFO="${PLUGIN_DIR}/.cache/device_info"
    RECORD_INFO="${PLUGIN_DIR}/.cache/game_info"
    UPGRADE_SHELL="${WORK_DIR}/scripts/xunyou_upgrade.sh"
    ACCELERATE_SHELL="${WORK_DIR}/scripts/xunyou_accelerate.sh"
    DAEMON_LOG="${PLUGIN_DIR}/xunyou_daemon.log"
    CTRL_LOG="${WORK_DIR}/log/xunyou_ctrl.log"
    PROXY_LOG="${WORK_DIR}/log/xunyou_proxy.log"
    IPSET_LOG="${WORK_DIR}/log/xunyou_ipset.log"
    FILEWALL_SHELL="${PLUGIN_DIR}/firewall.sh"

    PLUGIN_VERSION=`cat ${PLUGIN_DIR}/version`
    if [ -z "${PLUGIN_VERSION}" ]; then
        log "Can't find the plugin version file!"
        return 1
    fi

    LAN_IF_ADDR=`ip address show ${LAN_IF_NAME} | grep "\<inet\>" | awk -F ' ' '{print $2}' | awk -F '/' '{print $1}'`
    if [ -z "${LAN_IF_ADDR}" ]; then
        log "Can't find the lan ip!"
        return 1
    fi

    LAN_IF_MAC=`ip address show ${LAN_IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${LAN_IF_MAC}" ]; then
        log "Can't find the lan mac!"
        return 1
    fi

    CORE_TAR="${PLUGIN_DIR}/xunyou.tar.gz"
    if [ ! -e ${CORE_TAR} ]; then
        log "Can't find plugin core file ${CORE_TAR}!"
        return 1
    fi

    local json
    local key

    if [ -f ${BIND_INFO} ]; then
        json=`cat ${BIND_INFO}`

        key="userName"
        USER_NAME=`get_json_value "${json}" "${key}"`
    fi

    json=`curl -s http://router.xunyou.com/index.php/Info/getClientIp` >/dev/null 2>&1
    if [ -n "${json}" ]; then
        key="ip"
        PUBLIC_IP=`get_json_value "${json}" "${key}"`
    fi

    NOHUP_CMD=`type -p nohup`

    KERNEL=`uname -r`

    rm -f ${DAEMON_LOG}*

    log "SYSTEM_TYPE=${SYSTEM_TYPE}"

    return 0
}

create_work_dir()
{
    if [ ! -d ${WORK_DIR} ]; then
        #释放核心插件包
        tar -C ${WORK_DIR%/*} -xzf ${CORE_TAR}

        local files

        #释放lib插件包
        files=`ls ${PLUGIN_DIR}/lib*.tar.gz` >/dev/null 2>&1
        for file in ${files}; do
            tar -C ${WORK_DIR%/*} -xzf ${file}
        done

        #释放ko插件包
        files=`ls ${PLUGIN_DIR}/ko*.tar.gz` >/dev/null 2>&1
        for file in ${files}; do
            tar -C ${WORK_DIR%/*} -xzf ${file}
        done
    fi
}

delete_work_dir()
{
    rm -rf ${WORK_DIR}
}

add_module()
{
    local ko_name=$1
    local ko_path

    local ret=`lsmod 2>/dev/null | grep ${ko_name}`
    if [ -z "${ret}" ]; then
        ko_path=`find /lib/modules/${KERNEL} -name ${ko_name}.ko`
        if [ -n "${ko_path}" ]; then
            insmod ${ko_path}
        else
            if [ -d ${WORK_DIR}/modules/${KERNEL} ]; then
                ko_path=`find ${WORK_DIR}/modules/${KERNEL} -name ${ko_name}.ko`
                if [ -n "${ko_path}" ]; then
                    insmod ${ko_path}
                fi
            fi
        fi
    fi
}

#测试ipset是否支持hash:net和hash:netport，1为支持，0为不支持。
test_ipset()
{
    local cmd=`type -p ipset`
    if [ -z "${cmd}" ]; then
        return 0
    fi

    ipset -exist create xunyou_test_port bitmap:port range 0-65535 >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    ipset destroy xunyou_test_port

    ipset -exist create xunyou_test_net hash:net >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    ipset destroy xunyou_test_net

    ipset -exist create xunyou_test_netport hash:net,port >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    iptables -t nat -A PREROUTING -m set --match-set xunyou_test_netport dst -p tcp -j RETURN >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        ipset destroy xunyou_test_netport
        return 0
    fi

    iptables -t nat -D PREROUTING -m set --match-set xunyou_test_netport dst -p tcp -j RETURN
    ipset destroy xunyou_test_netport

    return 1
}

#测试iptables是否支持hex-string，1为支持，0为不支持。
test_iptables_hexsting()
{
    iptables -t nat -A PREROUTING -i ${LAN_IF_NAME} -p udp --dport 53 -m string --hex-string "${PLUGIN_DOMAIN_HEX}" --algo kmp -j DNAT --to-destination ${LAN_IF_ADDR} >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        return 0
    fi

    iptables -t nat -D PREROUTING -i ${LAN_IF_NAME} -p udp --dport 53 -m string --hex-string "${PLUGIN_DOMAIN_HEX}" --algo kmp -j DNAT --to-destination ${LAN_IF_ADDR} >/dev/null 2>&1

    return 1
}

system_init()
{
    create_work_dir

    ulimit -n 2048

    add_module nf_defrag_ipv6
    add_module nf_tproxy_core
    add_module xt_TPROXY

    test_ipset
    if [ $? -eq 1 ]; then
        SUPPORT_IPSET="true"
    fi

    test_iptables_hexsting
    if [ $? -eq 1 ]; then
        SUPPORT_PLUGIN_DOMAIN="true"
    fi

    return 0
}

download()
{
    local url="$1"
    local file="$2"
    local md5="$3"

    curl -L -s -k "$url" -o "${file}" >/dev/null 2>&1 || \
        wget -q --no-check-certificate "$url" -O "${file}" >/dev/null 2>&1 || \
        curl -s -k "$url" -o "${file}" >/dev/null 2>&1

    if [ $? -ne 0 ]; then
        log "Failed: curl (-L) -s -k ${url} -o ${file} ||
            wget -q --no-check-certificate $url -O ${file}!"
        return 1
    fi

    if [ -n "$md5" ]; then
        local download_md5=`md5sum "${file}"`
        if [ $? -ne 0 ]; then
            log "Execute md5sum failed!"
            return 1
        fi

        download_md5=`echo ${download_md5} | awk '{print $1}' | tr [a-z] [A-Z]`

        if [ "$download_md5" != "$md5" ]; then
            log "The checksum of ${file} does not match!"
            return 1
        fi
    fi

    return 0
}

download_install_json()
{
    log "vendor=${VENDOR}, model=${MODEL}, version=${VERSION}"

    local resp_info_json=`curl -s -k -X POST -H "Content-Type: application/json" -d '{"alias":"'"${VENDOR}"'","model":"'"${MODEL}"'","version":"'"${VERSION}"'"}' "https://router.xunyou.com/index.php/vendor/get-info"` > /dev/null 2>&1
    if [ $? -ne 0 ] ;then
        log "Curl get info failed!"
        return 1
    fi

    #判断网站返回的info信息是否正确
    local key="id"
    local value=`get_json_value "${resp_info_json}" "${key}"`

    if [ -z "${value}" ];then
        log "Can't find id!"
        return 1
    fi

    if [ ${value} -ne 1 ];then
        log "The id is error: ${value}!"
        return 1
    fi

    #获取install.json的下载路径
    key="url"
    value=`get_json_value "${resp_info_json}" "${key}"`
    if [ -z "${value}" ];then
        log "Can't find the install json's url!"
        return 1
    fi

    local url=`echo ${value} | sed 's/\\\\//g'`

    download ${url} ${INSTALL_JSON}
    ret=$?
    if [ ${ret} -ne 0 ]; then
        return ${ret}
    fi

    #调整install.json文件的排版格式，便于后续解析
    sed 's/,/,\n/g' -i ${INSTALL_JSON}
    sed 's/{/{\n/g' -i ${INSTALL_JSON}
    sed 's/}/\n}/g' -i ${INSTALL_JSON}
    sed 's/ //g' -i ${INSTALL_JSON}

    return 0
}

check_upgrade()
{
    download_install_json
    if [ $? -ne 0 ]; then
        log "Failed to download install json file, now skip checking upgrade."
        return 0
    fi

    #比较版本号
    local line=`grep '"version"' ${INSTALL_JSON}`
    local version=`echo ${line#*:} | tr -d '",'`

    major_number=`echo ${version} | cut -d. -f1`
    minor_number=`echo ${version} | cut -d. -f2`
    revision_number=`echo ${version} | cut -d. -f3`
    build_number=`echo ${version} | cut -d. -f4`

    cur_major_number=`echo ${PLUGIN_VERSION} | cut -d. -f1 | tr -d "Vv"`
    cur_minor_number=`echo ${PLUGIN_VERSION} | cut -d. -f2`
    cur_revision_number=`echo ${PLUGIN_VERSION} | cut -d. -f3`
    cur_build_number=`echo ${PLUGIN_VERSION} | cut -d. -f4`

    rm -f ${INSTALL_JSON}

    if [ ${major_number} -gt ${cur_major_number} ]; then
        return 1
    elif [ ${major_number} -eq ${cur_major_number} ]; then
        if [ ${minor_number} -gt ${cur_minor_number} ]; then
            return 1
        elif [ ${minor_number} -eq ${cur_minor_number} ]; then
            if [ ${revision_number} -gt ${cur_revision_number} ]; then
                return 1
            elif [ ${revision_number} -eq ${cur_revision_number} ]; then
                if [ ${build_number} -gt ${cur_build_number} ]; then
                    return 1
                fi
            fi
        fi
    fi

    return 0
}

exec_upgrade()
{
    #小米路由器不进行自升级
    if [ "${SYSTEM_TYPE}" == "xiaomi" ]; then
        return 0
    fi

    mkdir -p ${INSTALL_DIR}

    check_upgrade
    if [ $? -eq 0 ]; then
        log "The version of plugin is latest."
        rm -rf ${INSTALL_DIR}
        return 0
    else
        log "Find new version, now begin to upgrade the plugin."

        #下载安装包
        download ${INSTALL_TAR_URL} ${INSTALL_TAR}
        if [ $? -ne 0 ]; then
            log "Failed to download ${INSTALL_TAR}."
            return 1
        fi

        #解压缩安装包
        tar -C ${INSTALL_DIR} -xzf ${INSTALL_TAR}

        #执行安装更新程序
        sh ${INSTALL_SHELL} &

        exit
    fi

    return 0
}

restart_dnsmasq_proc()
{
    local start_cmd=$1

    local prev_pid=`ps -w | grep dnsmasq | grep -v grep | grep -v '\[dnsmasq\]' | awk -F" " '{print $1}'`

    if [ -n "${start_cmd}" ]; then
        kill ${prev_pid}
        ${start_cmd}
    else
        case ${SYSTEM_TYPE} in
        "merlin")
            service restart_dnsmasq >/dev/null 2>&1
            ;;
        "asus")
            service restart_dnsmasq >/dev/null 2>&1
            ;;
        "oray")
            /etc/init.d/dnsmasq restart >/dev/null 2>&1
            ;;
        "koolshare")
            /etc/init.d/dnsmasq restart >/dev/null 2>&1
            ;;
        "xiaomi")
            /etc/init.d/dnsmasq restart >/dev/null 2>&1
            ;;
        "netgear")
            local cmd=`ps -w | grep dnsmasq | grep -v grep | awk -F" " '{for (i=5;i<=NF;i++) printf $i" "}'`
            kill ${prev_pid} >/dev/null 2>&1
            ${cmd} >/dev/null 2>&1
            ;;
        *)
            ;;
        esac
    fi

    local i=0
    while [ $i -lt 5 ]
    do
        local cur_pid=`ps -w | grep dnsmasq | grep -v grep | grep -v '\[dnsmasq\]' | awk -F" " '{print $1}'`

        if [ -n "${cur_pid}" -a "${cur_pid}" != "${prev_pid}" ]; then
            return 0
        fi

        sleep 1
        let i++
    done

    return 1
}

clear_domain()
{
    if [ "${SUPPORT_PLUGIN_DOMAIN}" == "false" ]; then
        return 0
    fi

    #网件的路由器把插件域名作为内部域名处理的，不需要我们修改dnsmasq配置
    if [ "${SYSTEM_TYPE}" == "netgear" ]; then
        return 0
    fi

    local cmd=`ps -w | grep dnsmasq | grep -v grep | grep -v '\[dnsmasq\]' | awk -F" " 'NR==1 {for (i=5;i<=NF;i++) print $i}'`

    #有dnsmasq进程时，恢复dnsmasq配置并重启dnsmasq进程
    if [ -n "${cmd}" ]; then
        local find_arg_c=0
        local dnsmasq_conf
        local start_cmd

        for arg in `echo ${cmd}`; do
            if [ ${find_arg_c} -eq 1 ]; then
                dnsmasq_conf="${arg}"
                break
            elif [ ${arg} == "-C" ]; then
                find_arg_c=1
            fi
        done

        if [ -z "${dnsmasq_conf}" ]; then
            dnsmasq_conf="/etc/dnsmasq.conf"
        fi

        if [ -n "${dnsmasq_conf}" -a -f ${dnsmasq_conf} ]; then
            log "Find dnsmasq configuration file: ${dnsmasq_conf}."

            local conf_dir=`awk -F "=" '$1=="conf-dir" {print $2}' ${dnsmasq_conf}`
            local addn_hosts=`awk -F "=" '$1=="addn-hosts" {print $2}' ${dnsmasq_conf}`

            if [ -n "${conf_dir}" -a -d ${conf_dir} ]; then
                rm -f ${conf_dir}/xunyou*
            elif [ -n "${addn_hosts}" ]; then
                if [ -d ${addn_hosts} ]; then
                    rm -f ${addn_hosts%*/}/${PLUGIN_DOMAIN}
                    rm -f ${addn_hosts%*/}/${OLD_PLUGIN_DOMAIN}
                else
                    sed -i "/${PLUGIN_DOMAIN}/d" ${addn_hosts}
                    sed -i "/${OLD_PLUGIN_DOMAIN}/d" ${addn_hosts}
                fi
            else
               rm -f ${WORK_DIR}\/conf\/hosts
               start_cmd=`echo ${cmd} | sed "s#--addn-hosts=${WORK_DIR}/conf/hosts##g"`
            fi
        else
            rm -f ${WORK_DIR}\/conf\/hosts
            start_cmd=`echo ${cmd} | sed "s#--addn-hosts=${WORK_DIR}/conf/hosts##g"`
        fi

        restart_dnsmasq_proc "${start_cmd}"
        if [ $? -ne 0 ]; then
            log "Failed to restart dnsmasq!"
            return 1
        fi
    else
        sed -i "/${PLUGIN_DOMAIN}/d" /etc/hosts
        sed -i "/${OLD_PLUGIN_DOMAIN}/d" /etc/hosts
    fi

    return 0
}

config_domain()
{
    if [ "${SUPPORT_PLUGIN_DOMAIN}" == "false" ]; then
        return 0
    fi

    #网件的路由器把插件域名作为内部域名处理的，不需要我们修改dnsmasq配置
    if [ "${SYSTEM_TYPE}" == "netgear" ]; then
        return 0
    fi

    local cmd=`ps -w | grep dnsmasq | grep -v grep | grep -v '\[dnsmasq\]' | awk -F" " 'NR==1 {for (i=5;i<=NF;i++) print $i}'`

    #有dnsmasq进程时，修改dnsmasq配置并重启dnsmasq进程
    if [ -n "${cmd}" ]; then
        local find_arg_c=0
        local dnsmasq_conf
        local start_cmd

        for arg in `echo ${cmd}`; do
            if [ ${find_arg_c} -eq 1 ]; then
                dnsmasq_conf="${arg}"
                break
            elif [ ${arg} == "-C" ]; then
                find_arg_c=1
            fi
        done

        if [ -z "${dnsmasq_conf}" ]; then
            dnsmasq_conf="/etc/dnsmasq.conf"
        fi

        if [ -n "${dnsmasq_conf}" -a -f ${dnsmasq_conf} ]; then
            log "Find dnsmasq configuration file: ${dnsmasq_conf}."

            local conf_dir=`awk -F "=" '$1=="conf-dir" {print $2}' ${dnsmasq_conf}`
            local addn_hosts=`awk -F "=" '$1=="addn-hosts" {print $2}' ${dnsmasq_conf}`

            if [ -n "${conf_dir}" -a -d ${conf_dir} ]; then
                echo "address=/${PLUGIN_DOMAIN}/${LAN_IF_ADDR}" > ${conf_dir}/xunyou
                echo "address=/${OLD_PLUGIN_DOMAIN}/${LAN_IF_ADDR}" >> ${conf_dir}/xunyou
                echo "local-ttl=120" >> ${conf_dir}/xunyou
            elif [ -n "${addn_hosts}" ]; then
                if [ -d ${addn_hosts} ]; then
                    echo "${LAN_IF_ADDR} ${PLUGIN_DOMAIN}" > ${addn_hosts%*/}/${PLUGIN_DOMAIN}
                    echo "${LAN_IF_ADDR} ${OLD_PLUGIN_DOMAIN}" > ${addn_hosts%*/}/${OLD_PLUGIN_DOMAIN}
                else
                    sed -i "/${PLUGIN_DOMAIN}/d" ${addn_hosts}
                    echo "${LAN_IF_ADDR} ${PLUGIN_DOMAIN}" >> ${addn_hosts}
                    sed -i "/${OLD_PLUGIN_DOMAIN}/d" ${addn_hosts}
                    echo "${LAN_IF_ADDR} ${OLD_PLUGIN_DOMAIN}" >> ${addn_hosts}
                fi
            else
                echo "${LAN_IF_ADDR} ${PLUGIN_DOMAIN}" > ${WORK_DIR}/conf/hosts
                echo "${LAN_IF_ADDR} ${OLD_PLUGIN_DOMAIN}" >> ${WORK_DIR}/conf/hosts

                start_cmd="${cmd} --addn-hosts=${WORK_DIR}/conf/hosts"
            fi
        else
            echo "${LAN_IF_ADDR} ${PLUGIN_DOMAIN}" > ${WORK_DIR}/conf/hosts
            echo "${LAN_IF_ADDR} ${OLD_PLUGIN_DOMAIN}" >> ${WORK_DIR}/conf/hosts

            start_cmd="${cmd} --addn-hosts=${WORK_DIR}/conf/hosts"
        fi

        restart_dnsmasq_proc "${start_cmd}"
        if [ $? -ne 0 ]; then
            log "Failed to restart dnsmasq!"
            return 1
        fi
    else
        sed -i "/${PLUGIN_DOMAIN}/d" /etc/hosts
        echo "${LAN_IF_ADDR} ${PLUGIN_DOMAIN}" >> /etc/hosts
        sed -i "/${OLD_PLUGIN_DOMAIN}/d" /etc/hosts
        echo "${LAN_IF_ADDR} ${OLD_PLUGIN_DOMAIN}" >> /etc/hosts
    fi

    return 0
}

check_firewall()
{
    ${FILEWALL_SHELL} status >> ${DAEMON_LOG}
    if [ $? -ne 0 ]; then
        return 1
    fi

    return 0
}

close_firewall()
{
    ${FILEWALL_SHELL} close

    if [ ${SUPPORT_IPSET} == "true" ]; then
        ipset destroy xunyou_black_net_port >/dev/null 2>&1
        ipset destroy xunyou_grey_net_port >/dev/null 2>&1
        ipset destroy xunyou_white_net_port >/dev/null 2>&1

        ipset destroy xunyou_black_tcp_net >/dev/null 2>&1
        ipset destroy xunyou_grey_tcp_net >/dev/null 2>&1
        ipset destroy xunyou_white_tcp_net >/dev/null 2>&1

        ipset destroy xunyou_black_udp_net >/dev/null 2>&1
        ipset destroy xunyou_grey_udp_net >/dev/null 2>&1
        ipset destroy xunyou_white_udp_net >/dev/null 2>&1

        ipset destroy xunyou_black_tcp_port >/dev/null 2>&1
        ipset destroy xunyou_grey_tcp_port >/dev/null 2>&1
        ipset destroy xunyou_white_tcp_port >/dev/null 2>&1

        ipset destroy xunyou_black_udp_port >/dev/null 2>&1
        ipset destroy xunyou_grey_udp_port >/dev/null 2>&1
        ipset destroy xunyou_white_udp_port >/dev/null 2>&1
    fi

    return 0
}

open_firewall()
{
    ${FILEWALL_SHELL} open

    return 0
}

clear_conf()
{
    rm -f ${PLUGIN_CONF}
    return 0
}

config_conf()
{
    echo "{" > ${PLUGIN_CONF}
    echo "    \"pluginVer\":\"${PLUGIN_VERSION}\"," >> ${PLUGIN_CONF}
    echo "    \"systemType\":\"${SYSTEM_TYPE}\"," >> ${PLUGIN_CONF}
    echo "    \"builtIn\":${BUILTIN}," >> ${PLUGIN_CONF}
    echo "    \"supportIpset\":${SUPPORT_IPSET}," >> ${PLUGIN_CONF}
    echo "    \"lanIf\":\"${LAN_IF_NAME}\"," >> ${PLUGIN_CONF}
    echo "    \"lanIp\":\"${LAN_IF_ADDR}\"," >> ${PLUGIN_CONF}
    echo "    \"lanMac\":\"${LAN_IF_MAC}\"," >> ${PLUGIN_CONF}
    echo "    \"routerVendor\":\"${VENDOR}\"," >> ${PLUGIN_CONF}
    echo "    \"routerModel\":\"${MODEL}\"," >> ${PLUGIN_CONF}
    echo "    \"routerVer\":\"${VERSION}\"," >> ${PLUGIN_CONF}
    echo "    \"bindInfo\":\"${BIND_INFO}\"," >> ${PLUGIN_CONF}
    echo "    \"deviceInfo\":\"${DEVICE_INFO}\"," >> ${PLUGIN_CONF}
    echo "    \"gameInfo\":\"${RECORD_INFO}\"," >> ${PLUGIN_CONF}
    echo "    \"ctrlLog\":\"${CTRL_LOG}\"," >> ${PLUGIN_CONF}
    echo "    \"proxyLog\":\"${PROXY_LOG}\"," >> ${PLUGIN_CONF}
    echo "    \"ipsetLog\":\"${IPSET_LOG}\"," >> ${PLUGIN_CONF}
    echo "    \"pluginDomain\":\"${PLUGIN_DOMAIN}\"," >> ${PLUGIN_CONF}
    echo "    \"dhcpLeases\":\"${DHCP_LEASES}\"" >> ${PLUGIN_CONF}
    echo "}" >> ${PLUGIN_CONF}

    return 0
}

#检查进程状态，正常返回0，否则返回1
check_process()
{
    local pid=`ps -w | grep ${CTRL_PROC} | grep -v grep | awk -F" " '{print $1}'`
    if [ -z "${pid}" ]; then
        log "${CTRL_PROC} process is not running!"
        post_log crash ${CTRL_PROC}
        return 1
    fi

    pid=`ps -w | grep ${PROXY_PROC} | grep -v grep | awk -F" " '{print $1}'`
    if [ -z "${pid}" ]; then
        log "${PROXY_PROC} process is not running!"
        post_log crash ${PROXY_PROC}
        return 1
    fi

    return 0
}

start_process()
{
    if [ "${SYSTEM_TYPE}" == "merlin" -o "${SYSTEM_TYPE}" == "asus" ]; then
        echo 1 > /proc/sys/vm/overcommit_memory
    fi

    export LD_LIBRARY_PATH=${WORK_DIR}/lib:${LD_LIBRARY_PATH}

    mkdir -p ${PLUGIN_DIR}/.cache

    ${NOHUP_CMD} ${WORK_DIR}/bin/${CTRL_PROC} --config ${PLUGIN_CONF} >/dev/null 2>&1 &
    ${NOHUP_CMD} ${WORK_DIR}/bin/${PROXY_PROC} --config ${PLUGIN_CONF} >/dev/null 2>&1 &

    local library_path=`echo ${LD_LIBRARY_PATH} | sed "s#${WORK_DIR}/lib:##g"`
    export LD_LIBRARY_PATH=${library_path}

    return 0
}

stop_process()
{
    killall ${CTRL_PROC} >/dev/null 2>&1
    killall ${PROXY_PROC} >/dev/null 2>&1

    rm -f /tmp/xunyou_*_fd

    return 0
}

start_plugin()
{
    create_work_dir
    config_domain
    config_conf
    open_firewall
    start_process
    post_log start
}

stop_plugin()
{
    stop_process
    close_firewall
    clear_conf
    clear_domain
    delete_work_dir
    post_log stop
}

restart_plugin()
{
    stop_plugin
    start_plugin
}

restart_plugin_with_upgrade()
{
    stop_plugin
    exec_upgrade
    start_plugin
}

#检查守护进程状态，0为正常，否则返回1
check_deamon()
{
    if [ -f ${PID_FILE} ]; then
        local deamon_pid=`cat ${PID_FILE}`
        local pid_list

        if [ ${SYSTEM_TYPE} == "merlin" ]; then
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '{print $1}'`
        else
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '{print $1}'`
        fi

        for pid in `echo ${pid_list}`
        do
            if [ "${pid}" == "${deamon_pid}" ]; then
                return 0
            fi
        done
    fi

    return 1
}

start_daemon()
{
    local self=$$
    local pid_list

    if [ ${SYSTEM_TYPE} == "merlin" ]; then
        pid_list=`sh -c 'subpid=$$;ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '"'"'$1!=$subpid {print $1}'"'"`
    else
        pid_list=`sh -c 'subpid=$$;ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '"'"'$1!=$subpid {print $1}'"'"`
    fi

    for pid in `echo ${pid_list}`
    do
        if [ "${pid}" != "${self}" ]; then
            echo "${pid}" > ${PID_FILE}
            break
        fi
    done

    while [ 1 ]
    do
        sleep 60

        check_process
        if [ $? -ne 0 ]; then
            restart_plugin
        fi

        check_firewall
        if [ $? -ne 0 ]; then
            restart_plugin
        fi
    done
}

stop_daemon()
{
    if [ -f ${PID_FILE} ]; then
        local deamon_pid=`cat ${PID_FILE}`
        local pid_list

        if [ ${SYSTEM_TYPE} == "merlin" ]; then
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh -e xunyou_status.sh -e S90XunYouAcc.sh | grep -v grep | awk -F" " '{print $1}'`
        else
            pid_list=`ps -w | grep -w -e xunyou_daemon.sh -e xunyou_config.sh | grep -v grep | awk -F" " '{print $1}'`
        fi

        for pid in `echo ${pid_list}`
        do
            if [ "${pid}" == "${deamon_pid}" ]; then
                kill -9 ${pid} >/dev/null 2>&1
                break
            fi
        done

        rm -f ${PID_FILE}
    fi
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

system_init

case ${ACTION} in
    "start")
        log "[start]: 启动迅游插件！"

        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin_with_upgrade
            start_daemon &
        fi
        ;;

    "check")
        log "[check]: 启动迅游插件！"

        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin_with_upgrade
            start_daemon &
        fi
        ;;

    "stop")
        log "[stop] 停止迅游插件"

        stop_daemon
        stop_plugin
        ;;

    "restart")
        log "[restart]: 重新启动迅游模块！"

        stop_daemon
        restart_plugin_with_upgrade
        start_daemon &
        ;;

    "app")
        log "[app]: 重新启动迅游模块！"

        stop_daemon
        restart_plugin_with_upgrade
        start_daemon &
        ;;

    "simple")
        log "[simple]: 启动迅游模块！"

        check_deamon
        if [ $? -eq 0 ]; then
            log "Daemon is running."
        else
            restart_plugin
            start_daemon &
        fi
        ;;

    "status")
        log "[status]: 查询迅游模块状态！"

        check_deamon
        if [ $? -ne 0 ]; then
            log "Daemon is not running."
            exit 1
        fi

        check_process
        if [ $? -ne 0 ]; then
            exit 1
        fi

        check_firewall
        if [ $? -ne 0 ]; then
            exit 1
        fi

        exit 0
        ;;

    *)
        http_response "$1"

        if [ "${xunyou_enable}" == "1" ]; then
            log "[default]: 启动迅游插件！"

            stop_daemon
            restart_plugin_with_upgrade
            start_daemon &
        else
            log "[default] 停止迅游插件"

            stop_daemon
            stop_plugin
        fi
        ;;
esac

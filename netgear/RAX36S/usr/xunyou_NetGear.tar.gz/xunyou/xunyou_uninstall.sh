#!/bin/sh

[ -f /etc/profile ] && . /etc/profile >/dev/null

ACTION=$1

SYSTEM_TYPE=""
PLUGIN_DIR=""
IF_NAME=""
IF_MAC=""
MODEL=""

USER_ID=""
USER_NAME=""

WORK_DIR="/tmp/xunyou"

POST_PROC="xunyou_post"

PUBLIC_IP=""

get_json_value()
{
    local json=${1}
    local key=${2}
    local line=`echo ${json} | tr -d "\n " | awk -F"[][}{,]" '{for(i=1;i<=NF;i++) {if($i~/^"'${key}'":/) print $i}}' | tr -d '"' | sed -n 1p`
    local value=${line#*:}
    echo ${value}
}

post_log()
{
    [ ! -e ${WORK_DIR}/bin/${POST_PROC} ] && return 0

    local tmp_file="/tmp/.xunyou_post.log"
    local time=`date +"%Y-%m-%d %H:%M:%S"`
    local guid=`echo -n ''${IF_MAC}'merlinrouterxunyou2020!@#$' | md5sum | awk -F ' ' '{print $1}'`

    local data='{"id":1003,"user":"${USER_NAME}","mac":"'${IF_MAC}'","data":{"type":8,"account":"${USER_NAME}","model":"'${MODEL}'","guid":"'${guid}'","mac":"'${IF_MAC}'","publicIp":"'${PUBLIC_IP}'","source":0,"reporttime":"'${time}'"}}'

    echo ${data} > ${tmp_file}

    ${WORK_DIR}/bin/${POST_PROC} -d "acceldata.xunyou.com" -p 9240 -f ${tmp_file} >/dev/null 2>&1

    rm -f ${tmp_file}
}

env_init()
{
    local hostname=`uname -n`

    if [ -d "/koolshare" ]; then
        SYSTEM_TYPE="merlin"
        PLUGIN_DIR="/koolshare/xunyou"
        IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/jffs" ]; then
        SYSTEM_TYPE="asus"
        PLUGIN_DIR="/jffs/xunyou"
        IF_NAME="br0"
        MODEL=`nvram get productid`
    elif [ -d "/var/tmp/misc2" ]; then
        SYSTEM_TYPE="linksys"
        PLUGIN_DIR="/var/tmp/misc2/xunyou"
        IF_NAME="br0"
        MODEL=`nvram kget modelNumber`
    elif [ -d "/etc/oray" ]; then
        SYSTEM_TYPE="oray"
        PLUGIN_DIR="/xunyou"
        IF_NAME="br-lan"
        MODEL=`cat /etc/device_info | grep DEVICE_REVISION |awk -F '"' '{print $2}'`
    else
        local hostname=`uname -n`
        if [ "${hostname}" == "XiaoQiang" ]; then
            SYSTEM_TYPE="xiaomi"
            PLUGIN_DIR="/userdisk/appdata/2882303761520108685"
            IF_NAME="br-lan"
            MODEL=`uci get /usr/share/xiaoqiang/xiaoqiang_version.version.HARDWARE`
        elif [ "${hostname}" == "ARS2" ]; then
            SYSTEM_TYPE="koolshare"
            PLUGIN_DIR="/xunyou"
            IF_NAME="eth1"
            MODEL="ARS2"
        else
            curl -s http://127.0.0.1/currentsetting.htm | tr '\r' '\n' > /tmp/.xunyou_tmp
            local model=`awk -F"=" '$1=="Model" {print $2}' /tmp/.xunyou_tmp`
            local version=`awk -F"=" '$1=="Firmware" {print $2}' /tmp/.xunyou_tmp`

            rm -f /tmp/.xunyou_tmp

            if [ -n ${model} -a -n ${version} ]; then
                SYSTEM_TYPE="netgear"
                PLUGIN_DIR="/data/xunyou"
                IF_NAME="br0"
                MODEL="${model}"
            else
                echo "Unknown system type!"
                return 1
            fi
        fi
    fi

    IF_MAC=`ip address show ${IF_NAME} | grep link/ether | awk -F ' ' '{print $2}'`
    if [ -z "${IF_MAC}" ]; then
        echo "Can't find the lan mac!"
        return 1
    fi

    local json
    local key

    if [ -f ${PLUGIN_DIR}/.cache/bind_info ]; then
        json=`cat ${PLUGIN_DIR}/.cache/bind_info`

        key="userId"
        USER_ID=`get_json_value "${json}" "${key}"`

        key="userName"
        USER_NAME=`get_json_value "${json}" "${key}"`
    fi

    json=`curl -s http://router.xunyou.com/index.php/Info/getClientIp` >/dev/null 2>&1
    if [ -n "${json}" ]; then
        key="ip"
        PUBLIC_IP=`get_json_value "${json}" "${key}"`
    fi

    return 0
}

unbind_user()
{
    if [ -z "${USER_ID}" ]; then
        return
    fi

    curl -s -k -X POST -H "Content-Type: application/json" -d '{"userid":"'${USER_ID}'"}' "https://router-wan.xunyou.com:9004/v2/core/removeuserrouter" >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "Failed to unbind user!"
    fi

    rm -f ${PLUGIN_DIR}/.cache/bind_info
}

stop_plugin()
{
    sh ${PLUGIN_DIR}/xunyou_daemon.sh stop
}

delete_plugin()
{
    rm -rf ${WORK_DIR} ${PLUGIN_DIR}

    if [ "${SYSTEM_TYPE}" == "merlin" ]; then
        rm -f /koolshare/webs/Module_xunyou.asp
        rm -f /koolshare/res/icon-xunyou.png
        rm -f /koolshare/scripts/uninstall_xunyou.sh /koolshare/scripts/xunyou_status.sh
        rm -f /koolshare/init.d/S90XunYouAcc.sh

        local values=`dbus list xunyou_ | cut -d "=" -f 1`
        for value in ${values}
        do
            dbus remove ${value}
        done

        values=`dbus list softcenter_module_xunyou_ | cut -d "=" -f 1`
        for value in ${values}
        do
            dbus remove ${value}
        done
    fi
}

env_init
if [ $? -ne 0 ]; then
    exit 1
fi

post_log

stop_plugin

if [ "${ACTION}" != "silent" ]; then
    unbind_user
fi

delete_plugin

#!/bin/sh

/opt/bitdefender/bin/bd stop

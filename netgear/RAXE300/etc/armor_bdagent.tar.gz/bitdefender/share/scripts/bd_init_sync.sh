#!/bin/sh

source "/opt/bitdefender/share/scripts/lib/utils.sh"

PERSISTENT_ROOT="/persistent-data"
TEMPORARY_ROOT="/tmp"
SHADOW_ROOT="/opt/bitdefender/share/shadow"
INITSCRIPTS_ROOT="/opt/bitdefender/share/scripts/init_sync.d"

set -e
set -x

create_bdcontainer_mark || true

rotate_log_files() {
    local max_files=6

    for path in $(ls -1tr ${1}.*); do
        local i=${path##*.}
        mv -f ${path} ${path%.*}.$((i + 1))
    done

    for path in $(ls ${1}.*); do
        if [ ${path##*.} -ge $max_files ]; then
            rm -f ${path} || true
        fi
    done
}

copy_always_overwritten() {
    DST_ROOT="$1"
    SRC_ROOT="$2"
    shift 2
    TO_OVERWRITE="$@"

    if [ -d "${SRC_ROOT}" ]; then
        for ENTRY in ${TO_OVERWRITE}; do
            if [ -d "${DST_ROOT}/${ENTRY}" ]; then
                rm -rf "${DST_ROOT}/${ENTRY}" || true
                mkdir -p "${DST_ROOT}/${ENTRY}"
                cp -RP "${SRC_ROOT}/${ENTRY}"/* "${DST_ROOT}/${ENTRY}"
            elif [ -f "${DST_ROOT}/${ENTRY}" ]; then
                mkdir -p "${DST_ROOT}/$(dirname ${ENTRY})"
                cp -P "${SRC_ROOT}/${ENTRY}" "${DST_ROOT}/${ENTRY}"
            elif [ ! -e "${DST_ROOT}/${ENTRY}" ]; then
                mkdir -p "${DST_ROOT}/$(dirname ${ENTRY})"
                cp -RP "${SRC_ROOT}/${ENTRY}" "${DST_ROOT}/${ENTRY}"
            fi
        done
    elif [ -f "${SRC_ROOT}" ] && [ "${SRC_ROOT: -7}" = ".tar.gz" -o "${SRC_ROOT: -4}" = ".tgz" ]; then
        for ENTRY in ${TO_OVERWRITE}; do
            rm -rf "${DST_ROOT}/${ENTRY}" || true
        done
        tar -C "${DST_ROOT}" -xzf "${SRC_ROOT}" ${TO_OVERWRITE} || true
    else
        echo "${SRC_ROOT} is neither a directory, nor a gzipped tar file."
        false
    fi
}

rotate_log_files "${PERSISTENT_ROOT}/$(basename ${0}).log" || true

# Shadow persistent dirs - if missing or empty, copy from shadow.
for ENTRY in "etc" "guster"; do
    if [ ! -d "${PERSISTENT_ROOT}/${ENTRY}" ] || [ -z "$(ls -A ${PERSISTENT_ROOT}/${ENTRY})" ]; then
        rm -rf "${PERSISTENT_ROOT}/${ENTRY}" || true
        tar -C "${PERSISTENT_ROOT}" -xzf "${SHADOW_ROOT}/${ENTRY}.tar.gz"
    fi
done

copy_always_overwritten "${PERSISTENT_ROOT}" "${SHADOW_ROOT}/etc.tar.gz" \
    "etc/bdnc.client_id" \
    "etc/bdnc.ini" \
    "etc/certs" \
    "etc/default_settings_public.pem" \
    "etc/env_keys.json" \
    "etc/guster_locations.json" \
    "etc/jsonrules" \
    "etc/logging" \
    "etc/parental_categories.json" \
    "etc/signal_mapper.json" \
    "etc/subscription.conf" \
    "etc/updater.conf"

# "Always there" temporary dirs.
for ENTRY in "var/run" "var/tmp" "var/tmp/guster"; do
    if [ ! -d "${TEMPORARY_ROOT}/${ENTRY}" ]; then
        rm -rf "${TEMPORARY_ROOT}/${ENTRY}" || true
        mkdir -p "${TEMPORARY_ROOT}/${ENTRY}"
    fi
done

# "Always there" persistent dirs.
for ENTRY in "var/arks" "var/crash" "var/log" "var/upd"; do
    if [ ! -d "${PERSISTENT_ROOT}/${ENTRY}" ]; then
        rm -rf "${PERSISTENT_ROOT}/${ENTRY}" || true
        mkdir -p "${PERSISTENT_ROOT}/${ENTRY}"
    fi
done

# FIXME: Handle this in a more generic way.
ln -sfn "../tmp/guster/guster_ipc.pipe" "${TEMPORARY_ROOT}/var/run/guster_ipc.pipe"


if [ -d "${INITSCRIPTS_ROOT}" ]; then
    for SCRIPT in $(echo "${INITSCRIPTS_ROOT}"/*.sh | sort); do
        "${SCRIPT}" || exit 1
    done
fi

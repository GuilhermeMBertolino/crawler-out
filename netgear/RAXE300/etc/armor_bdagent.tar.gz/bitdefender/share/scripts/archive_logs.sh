#!/bin/sh

ROOTDIR=/tmp/bitdefender_logs
mkdir -p ${ROOTDIR}
BDUPD_INFO=${ROOTDIR}/BDUPD_INFO
mkdir -p ${BDUPD_INFO}

STORAGEDATA=/opt/bitdefender/etc/storage.data
ETC_LOGGING=/opt/bitdefender/etc/logging
DAEMONSLOGS_PERSISTENT=/opt/bitdefender/var/log

DAEMONSLOGS_TMP_BASEDIR=/tmp/bdlogs
# don't archive bdroot directory
DAEMONSLOGS_TMP_EXCLUDE=${DAEMONSLOGS_TMP_BASEDIR}/$(echo opt/bitdefender | awk -F '/' '{print $1}')
# archive only the specific directory that contains the logs
DAEMONSLOGS_TMP_ALL=${DAEMONSLOGS_TMP_BASEDIR}/opt/bitdefender/var/log

for subdir in $(ls ${DAEMONSLOGS_TMP_BASEDIR}); do
	path=${DAEMONSLOGS_TMP_BASEDIR}/${subdir}
	if [ ${path} = ${DAEMONSLOGS_TMP_EXCLUDE} ]; then
		continue
	fi

	# concatenate this path to the list of paths we want to archive
	DAEMONSLOGS_TMP_ALL="${DAEMONSLOGS_TMP_ALL} ${path}"
done

GUSTERLOGS1=/opt/bitdefender/var/tmp/guster/log
GUSTERLOGS2=/opt/bitdefender/var/tmp/guster/events*log
GUSTERLOGS3=/opt/bitdefender/var/tmp/guster/gusterupd*log
GUSTERDUMPS=/opt/bitdefender/var/tmp/guster/tmp/crashes
BDDEVICES=/tmp/bddevices

# Other miscellaneous info.
cp /opt/bitdefender/bitdefender-release                ${ROOTDIR}
cp /tmp/bd_*_telemetry.*                          ${ROOTDIR} || true
ps -w                                           > ${ROOTDIR}/ps
dmesg                                           > ${ROOTDIR}/dmesg
/opt/bitdefender/bin/iptables -nvL -t filter         > ${ROOTDIR}/iptables-filter
/opt/bitdefender/bin/ip6tables -nvL -t filter        > ${ROOTDIR}/ip6tables-filter
LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/gtables -l -t detection > ${ROOTDIR}/gtables.detection
LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/gtables -l -t traffic   > ${ROOTDIR}/gtables.traffic
cp ${STORAGEDATA}                                 ${ROOTDIR}/storage.data
LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/bdsett -get-key -recursive true /tmp   >> ${ROOTDIR}/storage.data
top -b -n 1                                     > ${ROOTDIR}/top
uptime                                          > ${ROOTDIR}/uptime
date -R                                         > ${ROOTDIR}/date
df -h                                           > ${ROOTDIR}/df

#bdupd info
cp /opt/bitdefender/etc/bdupd.server ${BDUPD_INFO}
cp /opt/bitdefender/var/upd/* ${BDUPD_INFO}

# ensure that the tar command will not fail with:
# "tar: /tmp/bddevices: Cannot stat: No such file or directory"
mkdir -p ${BDDEVICES}

# Create the archive.
ARNAME=bitdefender_logs.tar.gz

tar -czf /tmp/${ARNAME} -C ${ROOTDIR} . ${ETC_LOGGING} ${DAEMONSLOGS_PERSISTENT} ${DAEMONSLOGS_TMP_ALL} ${GUSTERLOGS1} ${GUSTERLOGS2} ${GUSTERLOGS3} ${GUSTERDUMPS} ${BDDEVICES}
rm -rf ${ROOTDIR}

# Encrypt the archive.
PUBKEY=/opt/bitdefender/etc/logs-pub.pem
ENCSYMKEY=bitdefender_key.enc
TEMPKEY=/tmp/bitdefender-sym-key-temp

LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/bdcrypto gen-sym-key -k ${TEMPKEY}
LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/bdcrypto aes-encrypt -k ${TEMPKEY} -i /tmp/${ARNAME} -o /tmp/${ARNAME}.enc
LD_LIBRARY_PATH=/opt/bitdefender/lib /opt/bitdefender/bin/bdcrypto rsa-encrypt -k ${PUBKEY} -i ${TEMPKEY} -o /tmp/${ENCSYMKEY}

tar -czf /tmp/${ARNAME} -C /tmp ${ENCSYMKEY} ${ARNAME}.enc
rm -f /tmp/${ENCSYMKEY} /tmp/${ARNAME}.enc ${TEMPKEY}


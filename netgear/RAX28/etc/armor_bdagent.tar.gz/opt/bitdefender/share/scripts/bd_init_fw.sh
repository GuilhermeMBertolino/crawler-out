#!/bin/sh

BD_BIN="/opt/bitdefender/bin"
BOX_IPTABLES="${BD_BIN}/iptables"
BOX_IP6TABLES="${BD_BIN}/ip6tables"

source "/opt/bitdefender/share/scripts/lib/utils.sh"

init_chains() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    # iptables: the jump from FORWARD to BD_FILTER is not managed by the BD agent.
    $IPTABLES -N BD_FILTER >/dev/null 2>&1
    # iptables: the jump from INPUT to BD_INPUT is not managed by the BD agent.
    $IPTABLES -N BD_INPUT >/dev/null 2>&1
    # iptables: the jump from OUTPUT to BD_OUTPUT is not managed by the BD agent.
    $IPTABLES -N BD_OUTPUT >/dev/null 2>&1

    $IPTABLES -N WHITELIST >/dev/null 2>&1
    $IPTABLES -N IGNORED_DEVICES >/dev/null 2>&1
    $IPTABLES -N GUSTER >/dev/null 2>&1
}

uninit_chains() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    for chain in BD_INPUT BD_OUTPUT BD_FILTER WHITELIST IGNORED_DEVICES GUSTER; do
        $IPTABLES -F ${chain} >/dev/null 2>&1
    done
}

case "$1" in
    start)
        init_chains
        init_chains -6
    ;;
    stop)
        uninit_chains
        uninit_chains -6
    ;;
    *)
        init_chains
        init_chains -6
        run "${BD_BIN}/bdexchange-pump" -t ":reinit_guster_chain" >/dev/null 2>&1
        run "${BD_BIN}/bdexchange-pump" -t ":reinit_dynamic_chains" >/dev/null 2>&1
    ;;
esac

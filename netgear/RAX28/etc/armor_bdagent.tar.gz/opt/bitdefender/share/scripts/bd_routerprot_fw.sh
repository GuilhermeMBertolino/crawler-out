#!/bin/sh

DIR="/opt/bitdefender"
BIN_DIR="$DIR/bin"
BOX_IPTABLES="$BIN_DIR/iptables"
BOX_IP6TABLES="$BIN_DIR/ip6tables"

add_routerprot_rules() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    "${IPTABLES}" -N BD_INPUT >/dev/null 2>&1
    "${IPTABLES}" -N BD_OUTPUT >/dev/null 2>&1
    "${IPTABLES}" -L BD_INPUT && "${IPTABLES}" -L BD_OUTPUT
    [ $? -ne 0 ] && exit 1

    local mark_shift="$(${BIN_DIR}/gtables -get_mark_shift)"
    local mark_whitelist="$(printf '0x%x' $((0x3 << ${mark_shift})))"
    local mark_mask="$(printf '0x%x' $((0x7 << ${mark_shift})))"

    # [CHS-2098] Router Protection feature:
    # 1) Skip invalid packets.
    # 2) Whitelist both inbound and outbout traffic on GID-owned connections
    #    initiated by the router (keep GID in sync with bd::gusterutl::setgid).
    # 3) Forward everything else to GhostR scanning.
    "${IPTABLES}" -F BD_OUTPUT
    "${IPTABLES}" -A BD_OUTPUT -m state --state INVALID -j RETURN
    "${IPTABLES}" -A BD_OUTPUT -m mark --mark 0x0/"${mark_mask}" -m owner --gid-owner 5555 -j MARK --set-xmark "${mark_whitelist}"/"${mark_mask}"
    "${IPTABLES}" -A BD_OUTPUT -j GUSTER

    "${IPTABLES}" -F BD_INPUT
    "${IPTABLES}" -A BD_INPUT -j GUSTER
}

del_routerprot_rules() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    "${IPTABLES}" -L BD_INPUT && "${IPTABLES}" -L BD_OUTPUT
    [ $? -ne 0 ] && exit 1

    "${IPTABLES}" -F BD_INPUT
    "${IPTABLES}" -F BD_OUTPUT

    return 0
}

[ $# -ne 1 ] && exit 1

case "$1" in
    add)
        add_routerprot_rules
        add_routerprot_rules -6
    ;;
    del)
        del_routerprot_rules
        del_routerprot_rules -6
    ;;
    *)
        exit 1
    ;;
esac


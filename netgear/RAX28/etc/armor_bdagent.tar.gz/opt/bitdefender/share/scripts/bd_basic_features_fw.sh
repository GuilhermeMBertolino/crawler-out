#!/bin/sh

DIR="/opt/bitdefender"
BIN_DIR="$DIR/bin"
BOX_IPTABLES="$BIN_DIR/iptables"
BOX_IP6TABLES="$BIN_DIR/ip6tables"

add_basic_feature_rules() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    "${IPTABLES}" -N BD_FILTER >/dev/null 2>&1
    "${IPTABLES}" -L BD_FILTER >/dev/null 2>&1
    [ $? -ne 0 ] && exit 1

    "${IPTABLES}" -N IGNORED_DEVICES >/dev/null 2>&1
    "${IPTABLES}" -L IGNORED_DEVICES >/dev/null 2>&1
    [ $? -ne 0 ] && exit 1

    "${IPTABLES}" -C BD_FILTER -j IGNORED_DEVICES >/dev/null 2>&1 || "${IPTABLES}" -I BD_FILTER 1 -j IGNORED_DEVICES
    "${IPTABLES}" -C BD_FILTER -p tcp ! --dport 53 ! --sport 53 -j GUSTER >/dev/null 2>&1 || "${IPTABLES}" -I BD_FILTER 2 -p tcp ! --dport 53 ! --sport 53 -j GUSTER
}

del_basic_feature_rules() {
    [ "$1" = "-6" ] && IPTABLES="${BOX_IP6TABLES}" || IPTABLES="${BOX_IPTABLES}"

    "${IPTABLES}" -L BD_FILTER >/dev/null 2>&1
    [ $? -ne 0 ] && exit 1

    "${IPTABLES}" -D BD_FILTER -j IGNORED_DEVICES
    "${IPTABLES}" -D BD_FILTER -p tcp ! --dport 53 ! --sport 53 -j GUSTER

    return 0
}

[ $# -ne 1 ] && exit 1

case "$1" in
    add)
        add_basic_feature_rules
        add_basic_feature_rules -6
    ;;
    del)
        del_basic_feature_rules
        del_basic_feature_rules -6
    ;;
    *)
        exit 1
    ;;
esac

